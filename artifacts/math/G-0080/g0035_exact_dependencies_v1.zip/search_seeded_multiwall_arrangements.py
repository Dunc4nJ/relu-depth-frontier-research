#!/usr/bin/env python3
"""Exact construction search over 3--5 seeded affine walls of J2.

The wall library is the full ``S3 x D4`` orbit, modulo an independent sign
for each wall, of the three strict-sign survivors A, B, and C from the
off-vertex classification.  Unordered wall sets are again quotiented by the
joint action of ``S3 x D4``.  Thus this is a finite, deliberately seeded
search rather than an enumeration of arbitrary rational walls.

Every arrangement is reconstructed over ``fractions.Fraction``.  After each
cut the current cell's exact edge graph is recomputed, which retains vertices
created by intersections of several walls.  A cell is constructively
certified in ``P^2`` either by a direct partition of its vertices into two
zonotope vertex sets or, for edge-scaling nullity at most three, by an exact
Minkowski decomposition into constructively certified extreme-ray summands.

A search hit requires a constructive certificate for every maximal cell.
Some misses additionally have a rigorous non-``P^2`` cell obstruction (a
full-dimensional simplex, or an edge-scaling-nullity-one cell with an exact
two-center-cover UNSAT result).  All other misses remain unresolved.  In
particular, zero hits says nothing beyond this finite seed library and these
sufficient construction predicates.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import sys
from collections import Counter
from fractions import Fraction as Q
from functools import lru_cache
from pathlib import Path
from typing import Iterable, Sequence

import z3

from analyze_survivor_type_cones import (
    nullspace_basis,
    scaling_cone_rays,
    scaling_system,
    summand_vertex_map,
)
from audit_four_wall_survivor import fixed_central_cover_query
from cone_join_obstruction import affine_rank, join_vertices, matrix_rank
from exact_zonotope import affine_coordinates, face_lattice, solve_square
from search_one_wall_refinements import cut_vertices, primitive_p2_partition, square_symmetries


Vector = tuple[Q, ...]
Wall = tuple[int, ...]
Cell = tuple[Vector, ...]

SEEDS: dict[str, Wall] = {
    "A": (-1, -1, -1, 1, 1, 1, 1),
    "B": (-1, -1, 1, 1, 1, 1, 1),
    "C": (-1, -1, 1, -1, 1, 1, 3),
}
EXPECTED_REPRESENTATIVE_COUNTS = {3: 30, 4: 75, 5: 153}


def dot(left: Sequence[Q], right: Sequence[Q]) -> Q:
    return sum((a * b for a, b in zip(left, right)), Q(0))


def normalize_wall(values: Sequence[int]) -> Wall:
    """Primitive canonical wall row, modulo reversal of its two sides."""
    divisor = math.gcd(*(abs(value) for value in values if value))
    if divisor == 0:
        raise ValueError("zero wall")
    primitive = tuple(value // divisor for value in values)
    reverse = tuple(-value for value in primitive)
    return min(primitive, reverse)


def symmetry_permutations() -> tuple[tuple[int, ...], ...]:
    permutations = tuple(
        tuple((*triangle, *(3 + index for index in square)))
        for triangle in itertools.permutations(range(3))
        for square in square_symmetries()
    )
    assert len(permutations) == 48 and len(set(permutations)) == 48
    return permutations


SYMMETRIES = symmetry_permutations()


def transform_wall(wall: Wall, permutation: Sequence[int]) -> Wall:
    return normalize_wall(tuple(wall[index] for index in permutation))


def wall_library() -> tuple[Wall, ...]:
    library = {
        transform_wall(seed, permutation)
        for seed in SEEDS.values()
        for permutation in SYMMETRIES
    }
    output = tuple(sorted(library))
    assert len(output) == 16
    assert all(wall[3] + wall[6] == wall[4] + wall[5] for wall in output)
    return output


def wall_provenance(library: Sequence[Wall]) -> dict[Wall, tuple[str, ...]]:
    provenance: dict[Wall, tuple[str, ...]] = {}
    for wall in library:
        names = tuple(sorted(
            name
            for name, seed in SEEDS.items()
            if wall in {transform_wall(seed, permutation) for permutation in SYMMETRIES}
        ))
        assert names
        provenance[wall] = names
    return provenance


def canonical_arrangement(walls: Iterable[Wall]) -> tuple[Wall, ...]:
    wall_tuple = tuple(walls)
    images = []
    for permutation in SYMMETRIES:
        images.append(tuple(sorted(transform_wall(wall, permutation) for wall in wall_tuple)))
    return min(images)


def arrangement_representatives(library: Sequence[Wall], wall_count: int) -> tuple[tuple[Wall, ...], ...]:
    representatives = tuple(
        walls
        for walls in itertools.combinations(library, wall_count)
        if canonical_arrangement(walls) == walls
    )
    expected = EXPECTED_REPRESENTATIVE_COUNTS.get(wall_count)
    if expected is not None:
        assert len(representatives) == expected
    return representatives


def affine_coefficients(vertices: Sequence[Vector], values: Sequence[int]) -> Vector:
    """Affine coefficients ``c,a_1,...,a_d`` from consistent vertex values."""
    if len(vertices) != len(values):
        raise ValueError("one value per vertex required")
    dimension = len(vertices[0])
    selected = next(
        indices
        for indices in itertools.combinations(range(len(vertices)), dimension + 1)
        if affine_rank(tuple(vertices[index] for index in indices)) == dimension
    )
    rows = tuple((Q(1), *vertices[index]) for index in selected)
    coefficients = solve_square(rows, tuple(Q(values[index]) for index in selected))
    assert coefficients is not None
    assert all(dot(coefficients, (Q(1), *vertex)) == Q(value) for vertex, value in zip(vertices, values))
    return coefficients


@lru_cache(maxsize=None)
def polytope_edges(points: Cell) -> tuple[tuple[int, int], ...]:
    coordinates = affine_coordinates(points)
    faces = face_lattice(coordinates)
    return tuple(sorted(
        tuple(sorted(face))
        for face in faces
        if len(face) == 2
        and affine_rank(tuple(coordinates[index] for index in face)) == 1
    ))


@lru_cache(maxsize=None)
def split_cell(points: Cell, coefficients: Vector) -> tuple[Cell, ...]:
    values = tuple(dot(coefficients, (Q(1), *point)) for point in points)
    if not (any(value < 0 for value in values) and any(value > 0 for value in values)):
        return (points,)
    edges = polytope_edges(points)
    children = tuple(sorted({
        tuple(sorted(cut_vertices(points, edges, values, side)))
        for side in (-1, 1)
    }))
    dimension = affine_rank(points)
    assert len(children) == 2
    assert all(affine_rank(child) == dimension for child in children)
    return children


J2_VERTEX_ORDER = join_vertices(2)
J2 = tuple(sorted(J2_VERTEX_ORDER))
J2_COEFFICIENTS = {
    wall: affine_coefficients(J2_VERTEX_ORDER, wall)
    for wall in wall_library()
}


@lru_cache(maxsize=None)
def arrangement_cells(walls: tuple[Wall, ...]) -> tuple[Cell, ...]:
    """Maximal cells, cached recursively on lexicographic wall prefixes."""
    if not walls:
        return (J2,)
    previous = arrangement_cells(walls[:-1])
    coefficients = J2_COEFFICIENTS[walls[-1]]
    cells = {
        child
        for cell in previous
        for child in split_cell(cell, coefficients)
    }
    return tuple(sorted(cells, key=lambda cell: (len(cell), cell)))


def convex_hull_vertices(points: Sequence[Vector]) -> Cell:
    unique = tuple(sorted(set(points)))
    if len(unique) <= 1:
        return unique
    coordinates = affine_coordinates(unique)
    singleton_indices = {
        next(iter(face))
        for face in face_lattice(coordinates)
        if len(face) == 1
    }
    assert singleton_indices
    return tuple(unique[index] for index in sorted(singleton_indices))


def all_one_ray_coefficients(rays: Sequence[Vector], nullity: int) -> tuple[Q, ...]:
    """Find an exact nonnegative representation of the all-one edge scaling."""
    edge_count = len(rays[0])
    for size in range(1, min(nullity, len(rays)) + 1):
        for ray_indices in itertools.combinations(range(len(rays)), size):
            selected_rays = tuple(rays[index] for index in ray_indices)
            if matrix_rank(selected_rays) != size:
                continue
            edge_indices = next(
                (
                    indices
                    for indices in itertools.combinations(range(edge_count), size)
                    if matrix_rank(tuple(
                        tuple(ray[edge] for ray in selected_rays)
                        for edge in indices
                    )) == size
                ),
                None,
            )
            assert edge_indices is not None
            rows = tuple(
                tuple(ray[edge] for ray in selected_rays)
                for edge in edge_indices
            )
            coefficients = solve_square(rows, (Q(1),) * size)
            assert coefficients is not None
            if any(coefficient < 0 for coefficient in coefficients):
                continue
            if not all(
                sum((coefficient * ray[edge] for coefficient, ray in zip(coefficients, selected_rays)), Q(0)) == 1
                for edge in range(edge_count)
            ):
                continue
            output = [Q(0)] * len(rays)
            for index, coefficient in zip(ray_indices, coefficients):
                output[index] = coefficient
            return tuple(output)
    raise AssertionError("extreme rays failed to generate the all-one scaling")


def encode_q(value: Q) -> list[int]:
    return [value.numerator, value.denominator]


def encode_vertex(vertex: Vector) -> list[list[int]]:
    return [encode_q(value) for value in vertex]


def cell_digest(points: Cell) -> str:
    payload = json.dumps([[encode_q(value) for value in point] for point in points], separators=(",", ":"))
    return hashlib.sha256(payload.encode()).hexdigest()


@lru_cache(maxsize=None)
def certify_cell(points: Cell) -> dict[str, object]:
    """Construction-first exact certificate, with selected rigorous obstructions."""
    dimension = affine_rank(points)
    assert dimension == len(points[0])
    primitive = primitive_p2_partition(points)
    base = {
        "cell_sha256": cell_digest(points),
        "vertex_count": len(points),
        "affine_dimension": dimension,
    }
    if primitive is not None:
        return {
            **base,
            "status": "certified_p2",
            "method": "direct_primitive_partition",
            "certificate": primitive,
        }

    if len(points) == dimension + 1:
        return {
            **base,
            "status": "rigorous_non_p2",
            "method": "full_dimensional_simplex",
            "reason": (
                "A simplex is Minkowski indecomposable, and every zonotope whose vertices are "
                "simplex vertices has dimension at most one; two such blocks cannot span this cell."
            ),
        }

    edges, rows = scaling_system(points)
    basis = nullspace_basis(rows, len(edges))
    nullity = len(basis)
    type_cone = {
        "edge_count": len(edges),
        "edge_scaling_rank": matrix_rank(rows),
        "edge_scaling_nullity": nullity,
    }

    if nullity == 1:
        result, _proof, _model = fixed_central_cover_query(points, 2)
        if result == z3.unsat:
            return {
                **base,
                **type_cone,
                "status": "rigorous_non_p2",
                "method": "indecomposable_two_center_unsat",
                "two_center_cover": str(result),
            }

    if 1 <= nullity <= 3:
        rays = scaling_cone_rays(basis)
        coefficients = all_one_ray_coefficients(rays, nullity)
        ray_records = []
        all_certified = True
        for ray_index, ray in enumerate(rays):
            vertex_map = summand_vertex_map(points, edges, ray)
            summand = convex_hull_vertices(vertex_map)
            certificate = primitive_p2_partition(summand) if affine_rank(summand) > 0 else None
            certified = certificate is not None
            all_certified = all_certified and certified
            ray_records.append({
                "ray_index": ray_index,
                "zero_edge_count": sum(value == 0 for value in ray),
                "summand_vertex_count": len(summand),
                "summand_affine_dimension": affine_rank(summand),
                "primitive_p2_certified": certified,
                "primitive_p2_certificate": certificate,
            })
        if all_certified:
            return {
                **base,
                **type_cone,
                "status": "certified_p2",
                "method": "complete_type_cone_extreme_ray_decomposition",
                "extreme_ray_count": len(rays),
                "all_one_ray_coefficients": [encode_q(value) for value in coefficients],
                "extreme_ray_summands": ray_records,
            }
        return {
            **base,
            **type_cone,
            "status": "unresolved",
            "method": "type_cone_has_uncertified_extreme_ray",
            "extreme_ray_count": len(rays),
            "all_one_ray_coefficients": [encode_q(value) for value in coefficients],
            "certified_extreme_ray_count": sum(record["primitive_p2_certified"] for record in ray_records),
            "extreme_ray_summands": ray_records,
        }

    return {
        **base,
        **type_cone,
        "status": "unresolved",
        "method": "type_cone_nullity_above_three",
    }


def delta4_positive_control() -> dict[str, object]:
    """Published G-0031 two-wall subdivision, through the same engine."""
    origin = (Q(0),) * 4
    simplex = (origin, *(tuple(Q(int(index == coordinate)) for coordinate in range(4)) for index in range(4)))
    walls = (
        (0, -1, 1, -1, 1),
        (0, -1, 1, 1, -1),
    )
    coefficients = tuple(affine_coefficients(simplex, wall) for wall in walls)
    cells: tuple[Cell, ...] = (tuple(sorted(simplex)),)
    for wall_coefficients in coefficients:
        cells = tuple(sorted({
            child
            for cell in cells
            for child in split_cell(cell, wall_coefficients)
        }, key=lambda cell: (len(cell), cell)))
    certificates = tuple(certify_cell(cell) for cell in cells)
    assert len(cells) == 4
    assert all(len(cell) == 6 and affine_rank(cell) == 4 for cell in cells)
    assert all(record["status"] == "certified_p2" for record in certificates)
    assert all(record["method"] == "direct_primitive_partition" for record in certificates)
    return {
        "polytope": "Delta_4",
        "wall_values": [list(wall) for wall in walls],
        "maximal_cell_count": len(cells),
        "maximal_cell_vertex_counts": [len(cell) for cell in cells],
        "all_cells_constructively_certified_p2": True,
        "certificate_methods": [record["method"] for record in certificates],
    }


def arrangement_record(walls: tuple[Wall, ...], include_cells: bool = False) -> dict[str, object]:
    cells = arrangement_cells(walls)
    diagnostics = []
    outcome = "constructive_hit"
    first_obstruction = None
    for cell in cells:
        diagnostic = certify_cell(cell)
        diagnostics.append(diagnostic)
        if diagnostic["status"] == "rigorous_non_p2":
            outcome = "rigorous_obstruction"
            first_obstruction = diagnostic
            break
        if diagnostic["status"] != "certified_p2":
            outcome = "unresolved"
    if outcome == "constructive_hit" and len(diagnostics) != len(cells):
        raise AssertionError("hit requires every maximal cell")
    record: dict[str, object] = {
        "walls": [list(wall) for wall in walls],
        "maximal_cell_count": len(cells),
        "maximal_cell_vertex_count_histogram": dict(sorted(Counter(map(len, cells)).items())),
        "inspected_cell_count": len(diagnostics),
        "outcome": outcome,
    }
    if first_obstruction is not None:
        record["first_obstruction"] = first_obstruction
    if outcome == "constructive_hit" or include_cells:
        record["cells"] = [
            {
                "vertices": [encode_vertex(vertex) for vertex in cell],
                "diagnostic": diagnostic,
            }
            for cell, diagnostic in zip(cells, diagnostics)
        ]
    return record


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wall-counts", type=int, nargs="+", default=(3, 4, 5))
    parser.add_argument("--output", type=Path)
    parser.add_argument("--progress-every", type=int, default=10)
    args = parser.parse_args()
    wall_counts = tuple(sorted(set(args.wall_counts)))
    if any(count not in EXPECTED_REPRESENTATIVE_COUNTS for count in wall_counts):
        raise SystemExit("--wall-counts must be drawn from 3, 4, 5")

    control = delta4_positive_control()
    library = wall_library()
    provenance = wall_provenance(library)
    searches = []
    hits = []
    obstruction_examples: dict[str, dict[str, object]] = {}
    global_outcomes: Counter[str] = Counter()
    global_obstruction_methods: Counter[str] = Counter()
    global_unresolved_methods: Counter[str] = Counter()
    total = sum(EXPECTED_REPRESENTATIVE_COUNTS[count] for count in wall_counts)
    completed = 0

    for wall_count in wall_counts:
        representatives = arrangement_representatives(library, wall_count)
        outcomes: Counter[str] = Counter()
        obstruction_methods: Counter[str] = Counter()
        unresolved_methods: Counter[str] = Counter()
        cell_count_histogram: Counter[int] = Counter()
        unresolved_arrangements = []
        first_obstruction_by_method: dict[str, dict[str, object]] = {}
        for walls in representatives:
            record = arrangement_record(walls)
            completed += 1
            outcomes[record["outcome"]] += 1
            global_outcomes[record["outcome"]] += 1
            cell_count_histogram[record["maximal_cell_count"]] += 1
            if record["outcome"] == "constructive_hit":
                hits.append(record)
                print(f"CONSTRUCTIVE HIT with {wall_count} walls: {record['walls']}", file=sys.stderr, flush=True)
            elif record["outcome"] == "rigorous_obstruction":
                diagnostic = record["first_obstruction"]
                method = diagnostic["method"]
                obstruction_methods[method] += 1
                global_obstruction_methods[method] += 1
                first_obstruction_by_method.setdefault(method, record)
                obstruction_examples.setdefault(method, record)
            else:
                cells = arrangement_cells(walls)
                unresolved = next(
                    certify_cell(cell)
                    for cell in cells
                    if certify_cell(cell)["status"] == "unresolved"
                )
                method = unresolved["method"]
                unresolved_methods[method] += 1
                global_unresolved_methods[method] += 1
                unresolved_arrangements.append({
                    "walls": record["walls"],
                    "maximal_cell_count": record["maximal_cell_count"],
                    "first_unresolved_cell": unresolved,
                })
            if args.progress_every > 0 and completed % args.progress_every == 0:
                print(
                    f"searched {completed}/{total}; hits={len(hits)}; "
                    f"cell-cache={certify_cell.cache_info().currsize}",
                    file=sys.stderr,
                    flush=True,
                )
        searches.append({
            "wall_count": wall_count,
            "joint_symmetry_representative_count": len(representatives),
            "outcome_histogram": dict(sorted(outcomes.items())),
            "maximal_cell_count_histogram": dict(sorted(cell_count_histogram.items())),
            "first_obstruction_method_histogram": dict(sorted(obstruction_methods.items())),
            "first_obstruction_examples": first_obstruction_by_method,
            "first_unresolved_method_histogram": dict(sorted(unresolved_methods.items())),
            "unresolved_arrangements": unresolved_arrangements,
        })

    project = Path(__file__).resolve().parents[3]
    report = {
        "schema": "g0035-seeded-multiwall-arrangement-search-v1",
        "arithmetic": "fractions.Fraction exact polyhedral reconstruction; Z3 exact LRA only for selected indecomposable obstructions",
        "wall_vertex_order": ["T0", "T1", "T2", "S00", "S10", "S01", "S11"],
        "seed_walls": SEEDS,
        "wall_library_contract": (
            "full S3 x D4 orbit of A/B/C, each wall independently quotiented by sign and "
            "primitive integer scaling"
        ),
        "wall_library_size": len(library),
        "wall_library": [
            {"values": list(wall), "seed_orbits": list(provenance[wall])}
            for wall in library
        ],
        "arrangement_symmetry": "unordered wall sets modulo the joint S3 x D4 action",
        "searches": searches,
        "total_joint_symmetry_representatives": total,
        "global_outcome_histogram": dict(sorted(global_outcomes.items())),
        "constructive_hit_count": len(hits),
        "constructive_hits": hits,
        "first_obstruction_method_histogram": dict(sorted(global_obstruction_methods.items())),
        "first_obstruction_examples": obstruction_examples,
        "first_unresolved_method_histogram": dict(sorted(global_unresolved_methods.items())),
        "unique_cells_certified_or_audited": certify_cell.cache_info().currsize,
        "positive_control": control,
        "interpretation": (
            "A constructive hit is an exact P2 subdivision certificate. A rigorous-obstruction "
            "outcome excludes only that displayed wall arrangement. An unresolved outcome means "
            "the sufficient construction predicate failed without a complete P2 decision."
        ),
        "no_claim": (
            "A zero hit count is only a bounded miss for the 3--5 wall sets drawn from this "
            "16-wall A/B/C seed orbit library. It does not exclude different ratios within the "
            "same sign orthants, other rational or affine walls, six or more walls, nonlinear "
            "subdivisions, virtual S2 cancellation, or unrestricted MAX11."
        ),
        "result": "PASS",
        "z3_version": z3.get_version_string(),
        "source_sha256": {
            "G-0031/README.md": sha256(project / "artifacts/math/G-0031/README.md"),
            "analyze_survivor_type_cones.py": sha256(Path(__file__).with_name("analyze_survivor_type_cones.py")),
            "exact_zonotope.py": sha256(Path(__file__).with_name("exact_zonotope.py")),
        },
    }
    encoded = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(encoded)
    print(json.dumps({
        "schema": report["schema"],
        "representatives": total,
        "outcomes": report["global_outcome_histogram"],
        "constructive_hits": len(hits),
        "unique_cells": report["unique_cells_certified_or_audited"],
        "positive_control": control["all_cells_constructively_certified_p2"],
        "result": report["result"],
    }, sort_keys=True))


if __name__ == "__main__":
    main()
