#!/usr/bin/env python3
"""Exact controls for the triangle--parallelogram join obstruction.

The noncanonical Delta_4 cells reproduced in G-0031 are joins of a segment
and a parallelogram.  Coning such a cell once more replaces the segment by a
triangle.  The accompanying report proves that this five-dimensional join is
Minkowski indecomposable and is not a primitive P^2 polytope, hence is not in
P^2 at all.

This script checks the finite combinatorics exactly and attacks the primitive
step independently with Z3 exact linear rational arithmetic.  It does not
prove the general Minkowski-summand lemma; that argument is written out in
README.md.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from fractions import Fraction as Q
from pathlib import Path
from typing import Iterable, Sequence

import z3


Vector = tuple[Q, ...]


def qvec(values: Iterable[int | Q]) -> Vector:
    return tuple(Q(value) for value in values)


def sub(a: Sequence[Q], b: Sequence[Q]) -> Vector:
    return tuple(x - y for x, y in zip(a, b))


def matrix_rank(rows: Sequence[Sequence[Q]]) -> int:
    matrix = [list(map(Q, row)) for row in rows]
    if not matrix:
        return 0
    nrows = len(matrix)
    ncols = len(matrix[0])
    rank = 0
    for column in range(ncols):
        pivot = next((row for row in range(rank, nrows) if matrix[row][column]), None)
        if pivot is None:
            continue
        matrix[rank], matrix[pivot] = matrix[pivot], matrix[rank]
        pivot_value = matrix[rank][column]
        matrix[rank] = [value / pivot_value for value in matrix[rank]]
        for row in range(nrows):
            if row == rank or not matrix[row][column]:
                continue
            coefficient = matrix[row][column]
            matrix[row] = [
                value - coefficient * pivot_entry
                for value, pivot_entry in zip(matrix[row], matrix[rank])
            ]
        rank += 1
    return rank


def affine_rank(points: Sequence[Vector]) -> int:
    return matrix_rank([sub(point, points[0]) for point in points[1:]]) if len(points) > 1 else 0


def join_vertices(simplex_dimension: int) -> tuple[Vector, ...]:
    """Vertices of Delta_p * [0,1]^2 in R^(p+3)."""
    p = simplex_dimension
    triangle_side: list[Vector] = [qvec([0] * (p + 3))]
    for coordinate in range(p):
        vertex = [0] * (p + 3)
        vertex[coordinate] = 1
        triangle_side.append(qvec(vertex))
    square_side = []
    for y0, y1 in ((0, 0), (1, 0), (0, 1), (1, 1)):
        vertex = [0] * (p + 3)
        vertex[p] = y0
        vertex[p + 1] = y1
        vertex[p + 2] = 1
        square_side.append(qvec(vertex))
    return tuple((*triangle_side, *square_side))


def join_edges_and_triangles(simplex_dimension: int) -> tuple[set[tuple[int, int]], set[tuple[int, int, int]]]:
    """The complete edge set and the triangular 2-faces used by the proof."""
    simplex_count = simplex_dimension + 1
    square = tuple(range(simplex_count, simplex_count + 4))
    simplex = tuple(range(simplex_count))
    square_edges = ((square[0], square[1]), (square[0], square[2]), (square[1], square[3]), (square[2], square[3]))
    edges: set[tuple[int, int]] = set()
    triangles: set[tuple[int, int, int]] = set()
    for u in simplex:
        for v in simplex:
            if u < v:
                edges.add((u, v))
    for edge in square_edges:
        edges.add(tuple(sorted(edge)))
    for u in simplex:
        for v in square:
            edges.add(tuple(sorted((u, v))))
    # Every simplex triangle is a face; for p=1 there is none.
    if simplex_dimension >= 2:
        for triple in itertools.combinations(simplex, 3):
            triangles.add(tuple(sorted(triple)))
    # Join(edge, vertex) in both directions gives a triangular 2-face.
    for u in simplex:
        for v in simplex:
            if u >= v:
                continue
            for z in square:
                triangles.add(tuple(sorted((u, v, z))))
    for u in simplex:
        for z0, z1 in square_edges:
            triangles.add(tuple(sorted((u, z0, z1))))
    return edges, triangles


def triangle_edge_graph_connected(simplex_dimension: int) -> dict[str, int | bool]:
    """Check that triangular faces force one scale on every polytope edge."""
    edges, triangles = join_edges_and_triangles(simplex_dimension)
    adjacency = {edge: set() for edge in edges}
    for triangle in triangles:
        triangle_edges = {
            tuple(sorted((triangle[0], triangle[1]))),
            tuple(sorted((triangle[0], triangle[2]))),
            tuple(sorted((triangle[1], triangle[2]))),
        }
        assert triangle_edges.issubset(edges)
        for edge in triangle_edges:
            adjacency[edge].update(triangle_edges - {edge})
    start = next(iter(edges))
    reached = {start}
    frontier = [start]
    while frontier:
        edge = frontier.pop()
        for other in adjacency[edge]:
            if other not in reached:
                reached.add(other)
                frontier.append(other)
    return {
        "edge_count": len(edges),
        "triangular_face_count": len(triangles),
        "edge_triangle_graph_connected": reached == edges,
        "reached_edge_count": len(reached),
    }


def z3_q(value: Q) -> z3.RatNumRef:
    return z3.RealVal(f"{value.numerator}/{value.denominator}")


def join_membership(point: Sequence[z3.ArithRef], simplex_dimension: int) -> z3.BoolRef:
    p = simplex_dimension
    x = point[:p]
    y0, y1, t = point[p], point[p + 1], point[p + 2]
    return z3.And(
        t >= 0,
        t <= 1,
        *(coordinate >= 0 for coordinate in x),
        z3.Sum(x) + t <= 1,
        y0 >= 0,
        y0 <= t,
        y1 >= 0,
        y1 <= t,
    )


def central_cover_query(simplex_dimension: int, center_count: int) -> tuple[z3.CheckSatResult, str | None, dict[str, object] | None]:
    vertices = join_vertices(simplex_dimension)
    ambient_dimension = simplex_dimension + 3
    centers = [
        [z3.Real(f"c_{simplex_dimension}_{center_count}_{group}_{coordinate}") for coordinate in range(ambient_dimension)]
        for group in range(center_count)
    ]
    colors = [z3.Int(f"color_{simplex_dimension}_{center_count}_{index}") for index in range(len(vertices))]
    solver = z3.Solver()
    solver.add(*(z3.And(color >= 0, color < center_count) for color in colors))
    for vertex_index, vertex in enumerate(vertices):
        for group in range(center_count):
            reflection = [
                2 * centers[group][coordinate] - z3_q(vertex[coordinate])
                for coordinate in range(ambient_dimension)
            ]
            solver.add(z3.Implies(colors[vertex_index] == group, join_membership(reflection, simplex_dimension)))
    result = solver.check()
    proof = str(solver.proof()) if result == z3.unsat else None
    model_payload: dict[str, object] | None = None
    if result == z3.sat:
        model = solver.model()
        model_payload = {
            "colors": [model.eval(color).as_long() for color in colors],
            "centers": [
                [str(model.eval(coordinate, model_completion=True)) for coordinate in center]
                for center in centers
            ],
        }
    return result, proof, model_payload


def planted_reflection_check(simplex_dimension: int, model: dict[str, object], center_count: int) -> bool:
    """Require a one-coordinate center corruption to break a SAT witness."""
    vertices = join_vertices(simplex_dimension)
    colors = model["colors"]
    raw_centers = model["centers"]
    assert isinstance(colors, list) and isinstance(raw_centers, list)

    def parse(value: str) -> Q:
        if value.startswith("(- ") and value.endswith(")"):
            return -parse(value[3:-1])
        return Q(value)

    centers = [[parse(value) for value in center] for center in raw_centers]

    def in_join(point: Sequence[Q]) -> bool:
        p = simplex_dimension
        x = point[:p]
        y0, y1, t = point[p], point[p + 1], point[p + 2]
        return (
            Q(0) <= t <= Q(1)
            and all(value >= 0 for value in x)
            and sum(x, Q(0)) + t <= 1
            and Q(0) <= y0 <= t
            and Q(0) <= y1 <= t
        )

    def witness_valid(candidate_centers: Sequence[Sequence[Q]]) -> bool:
        for vertex, color in zip(vertices, colors):
            center = candidate_centers[color]
            reflection = tuple(2 * center[index] - vertex[index] for index in range(len(vertex)))
            if not in_join(reflection):
                return False
        return True

    assert len(centers) == center_count and witness_valid(centers)
    corrupted = [list(center) for center in centers]
    corrupted[0][-1] += Q(1, 7)
    return not witness_valid(corrupted)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    segment_vertices = join_vertices(1)
    triangle_vertices = join_vertices(2)
    assert affine_rank(segment_vertices) == 4
    assert affine_rank(triangle_vertices) == 5

    segment_graph = triangle_edge_graph_connected(1)
    triangle_graph = triangle_edge_graph_connected(2)
    assert segment_graph["edge_triangle_graph_connected"] is True
    assert triangle_graph["edge_triangle_graph_connected"] is True

    z3.set_param(proof=True)
    p1_two, _, p1_model = central_cover_query(1, 2)
    p2_two, p2_proof, _ = central_cover_query(2, 2)
    p2_three, _, p2_three_model = central_cover_query(2, 3)
    assert p1_two == z3.sat and p1_model is not None
    assert p2_two == z3.unsat and p2_proof is not None
    assert p2_three == z3.sat and p2_three_model is not None
    assert planted_reflection_check(1, p1_model, 2)

    project = Path(__file__).resolve().parents[3]
    report = {
        "arithmetic": "fractions.Fraction plus Z3 exact QF_LIRA over rationals",
        "delta4_segment_join_parallelogram": {
            "ambient_affine_dimension": affine_rank(segment_vertices),
            "two_centrally_symmetric_sets": str(p1_two),
            "witness": p1_model,
            "edge_triangle_connectivity": segment_graph,
        },
        "delta5_triangle_join_parallelogram": {
            "ambient_affine_dimension": affine_rank(triangle_vertices),
            "two_centrally_symmetric_sets": str(p2_two),
            "three_sets_potency_mutation": str(p2_three),
            "three_set_witness": p2_three_model,
            "unsat_proof_chars": len(p2_proof),
            "unsat_proof_sha256": hashlib.sha256(p2_proof.encode()).hexdigest(),
            "edge_triangle_connectivity": triangle_graph,
        },
        "falsifier": "the exact SAT witness for p=1 fails after adding 1/7 to its first center's join coordinate",
        "no_claim": (
            "This rules out only keeping each coned G-0031 Delta4 cell intact as one P2 cell. "
            "It does not rule out subdividing that cone with additional walls, another P2 "
            "subdivision of Delta5 or Delta10, a virtual S2 identity, or unrestricted MAX11."
        ),
        "result": "PASS",
        "schema": "g0035-cone-join-obstruction-v1",
        "source_sha256": {
            "G-0022/THEOREMS.md": sha256(project / "artifacts/math/G-0022/THEOREMS.md"),
            "G-0031/README.md": sha256(project / "artifacts/math/G-0031/README.md"),
        },
        "z3_version": z3.get_version_string(),
    }
    encoded = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(encoded)
    print(json.dumps(report, sort_keys=True))


if __name__ == "__main__":
    main()
