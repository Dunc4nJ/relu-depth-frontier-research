#!/usr/bin/env python3
"""Exact reconstruction and first-cell audit of a four-wall J2 candidate.

The four wall rows are the canonical H0 x V3 survivor supplied by the
parallel discovery search.  This script independently reconstructs every
full-dimensional arrangement cell: after each halfspace cut it recomputes the
current polytope's exact edge graph, so intersections of several new walls
are not missed.

It then selects the lexicographically first smallest cell and seeks a
primitive P^2 partition before computing its complete nonnegative Minkowski
edge-scaling cone.  No conclusion about the full four-wall construction is
drawn unless a rigorous non-P^2 cell obstruction is obtained.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from fractions import Fraction as Q
from pathlib import Path
from typing import Sequence

import z3

from analyze_survivor_type_cones import (
    nullspace_basis,
    scaling_cone_rays,
    scaling_system,
    summand_vertex_map,
)
from audit_one_wall_obstructions import wall_coefficients
from cone_join_obstruction import affine_rank, join_vertices, matrix_rank, z3_q
from exact_zonotope import affine_coordinates, face_lattice
from prove_separating_wall_caps import active_normal_ranks, facet_halfspaces
from search_one_wall_refinements import cut_vertices, primitive_p2_partition


Vector = tuple[Q, ...]
WALLS = (
    (0, -1, 1, -1, 1, -1, 1),
    (0, -1, 1, 1, -1, 1, -1),
    (-1, 0, 1, -1, -1, 1, 1),
    (-1, 0, 1, 1, 1, -1, -1),
)
EXPECTED_VERTEX_COUNTS = (12, 12, 12, 12, 12, 12, 12, 13, 14, 14, 14, 14, 15, 15, 15, 15)


def wall_value(point: Sequence[Q], coefficients: Sequence[Q]) -> Q:
    constant, ax1, ax2, ay1, ay2, at = coefficients
    x1, x2, y1, y2, t = point
    return constant + ax1 * x1 + ax2 * x2 + ay1 * y1 + ay2 * y2 + at * t


def polytope_edges(points: Sequence[Vector]) -> tuple[tuple[int, int], ...]:
    coordinates = affine_coordinates(points)
    faces = face_lattice(coordinates)
    return tuple(sorted(
        tuple(sorted(face))
        for face in faces
        if len(face) == 2
        and affine_rank(tuple(coordinates[index] for index in face)) == 1
    ))


def cut_current_polytope(
    points: Sequence[Vector],
    coefficients: Sequence[Q],
    side: int,
) -> tuple[Vector, ...]:
    values = tuple(wall_value(point, coefficients) for point in points)
    edges = polytope_edges(points)
    return cut_vertices(points, edges, values, side)


def enumerate_full_cells() -> tuple[dict[str, object], ...]:
    original = join_vertices(2)
    coefficients = tuple(wall_coefficients(wall) for wall in WALLS)
    cells: dict[tuple[Vector, ...], list[tuple[int, ...]]] = {}
    for signs in itertools.product((-1, 1), repeat=len(WALLS)):
        points = original
        for side, wall in zip(signs, coefficients):
            if not points:
                break
            points = cut_current_polytope(points, wall, side)
            if not points or affine_rank(points) < 5:
                break
        if points and affine_rank(points) == 5:
            key = tuple(sorted(points))
            cells.setdefault(key, []).append(signs)
    records = tuple(sorted(
        (
            {
                "signs": [list(signs) for signs in sign_lists],
                "vertices": key,
                "vertex_count": len(key),
            }
            for key, sign_lists in cells.items()
        ),
        key=lambda record: (record["vertex_count"], record["signs"], record["vertices"]),
    ))
    assert len(records) == 16
    assert tuple(record["vertex_count"] for record in records) == EXPECTED_VERTEX_COUNTS
    assert all(len(record["signs"]) == 1 for record in records)
    return records


def encode_vertex(vertex: Vector) -> list[list[int]]:
    return [[coordinate.numerator, coordinate.denominator] for coordinate in vertex]


def fixed_central_cover_query(
    points: Sequence[Vector],
    center_count: int,
    want_proof: bool = False,
) -> tuple[z3.CheckSatResult, str | None, dict[str, object] | None]:
    halfspaces = facet_halfspaces(points)
    centers = [
        [z3.Real(f"four_wall_center_{center_count}_{group}_{coordinate}")
         for coordinate in range(len(points[0]))]
        for group in range(center_count)
    ]
    colors = [z3.Int(f"four_wall_color_{center_count}_{index}") for index in range(len(points))]
    solver = z3.Solver()
    solver.add(*(z3.And(color >= 0, color < center_count) for color in colors))
    for vertex_index, vertex in enumerate(points):
        for group in range(center_count):
            reflection = tuple(
                2 * centers[group][coordinate] - z3_q(vertex[coordinate])
                for coordinate in range(len(vertex))
            )
            membership = z3.And(*[
                z3.Sum(*[
                    z3_q(normal[coordinate]) * reflection[coordinate]
                    for coordinate in range(len(normal))
                ])
                <= z3_q(support)
                for normal, support in halfspaces
            ])
            solver.add(z3.Implies(colors[vertex_index] == group, membership))
    result = solver.check()
    proof = str(solver.proof()) if want_proof and result == z3.unsat else None
    model_payload = None
    if result == z3.sat:
        model = solver.model()
        model_payload = {
            "colors": [model.eval(color).as_long() for color in colors],
            "centers": [
                [str(model.eval(coordinate, model_completion=True)) for coordinate in center]
                for center in centers
            ],
        }
    return result, proof, model_payload


def first_cell_diagnostics(cell: dict[str, object]) -> dict[str, object]:
    points = tuple(cell["vertices"])
    primitive = primitive_p2_partition(points)
    edges, rows = scaling_system(points)
    basis = nullspace_basis(rows, len(edges))
    ray_records = []
    rays = None
    if len(basis) <= 3:
        rays = scaling_cone_rays(basis)
        assert matrix_rank(rays) == len(basis)
        for ray in rays:
            vertex_map = summand_vertex_map(points, edges, ray)
            polytope = tuple(sorted(set(vertex_map)))
            certificate = primitive_p2_partition(polytope)
            ray_records.append({
                "vertex_count": len(polytope),
                "affine_dimension": affine_rank(polytope),
                "primitive_p2_partition": certificate,
                "constructively_primitive_p2": certificate is not None,
                "vertices": [encode_vertex(vertex) for vertex in polytope],
            })
    obstruction = None
    if len(basis) == 1:
        two_center, proof, _model = fixed_central_cover_query(points, 2, want_proof=True)
        potency, _potency_proof, potency_model = fixed_central_cover_query(
            points,
            len(points),
        )
        assert two_center == z3.unsat and proof is not None
        assert potency == z3.sat and potency_model is not None
        halfspaces = facet_halfspaces(points)
        ranks = active_normal_ranks(points, halfspaces)
        barycenter = tuple(
            sum((point[coordinate] for point in points), Q(0)) / len(points)
            for coordinate in range(len(points[0]))
        )
        mutant_rank = active_normal_ranks((barycenter,), halfspaces)[0]
        assert min(ranks) == 5 and mutant_rank < 5
        obstruction = {
            "minkowski_indecomposable_from_nullity_one": True,
            "two_center_cover": str(two_center),
            "unsat_proof_chars": len(proof),
            "unsat_proof_sha256": hashlib.sha256(proof.encode()).hexdigest(),
            "potency_one_center_per_vertex": str(potency),
            "minimum_vertex_active_normal_rank": min(ranks),
            "ambient_dimension": 5,
            "planted_interior_barycenter_active_normal_rank": mutant_rank,
            "planted_nonvertex_rejected": True,
            "p2_conclusion": "cell is not in P2",
        }
    return {
        "signs": cell["signs"],
        "vertex_count": len(points),
        "affine_dimension": affine_rank(points),
        "vertices": [encode_vertex(vertex) for vertex in points],
        "primitive_p2_partition": primitive,
        "edge_count": len(edges),
        "edge_scaling_rank": matrix_rank(rows),
        "edge_scaling_nullity": len(basis),
        "scaling_cone_extreme_ray_count": len(rays) if rays is not None else None,
        "extreme_ray_summands": ray_records,
        "constructive_extreme_ray_decomposition_hit": (
            rays is not None and all(record["constructively_primitive_p2"] for record in ray_records)
        ),
        "complete_obstruction": obstruction,
        "status": (
            "rigorously outside P2; four-wall construction killed"
            if obstruction is not None
            else "diagnostic-only pending complete P2 audit"
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    z3.set_param(proof=True)
    cells = enumerate_full_cells()
    diagnostics = first_cell_diagnostics(cells[0])
    report = {
        "schema": "g0035-four-wall-survivor-first-cell-audit-v1",
        "arithmetic": "fractions.Fraction exact polyhedral reconstruction",
        "wall_vertex_order": ["T0", "T1", "T2", "S00", "S10", "S01", "S11"],
        "wall_values": [list(wall) for wall in WALLS],
        "full_cell_count": len(cells),
        "full_cell_vertex_counts": [cell["vertex_count"] for cell in cells],
        "cell_signs_by_size": [
            {"vertex_count": cell["vertex_count"], "signs": cell["signs"]}
            for cell in cells
        ],
        "smallest_cell": diagnostics,
        "construction_killed_by_smallest_cell": diagnostics["complete_obstruction"] is not None,
        "no_claim": (
            "The conclusion applies only to the displayed four-wall J2 arrangement. It does not "
            "exclude other four-wall choices, five or more walls, other subdivisions of J2, "
            "virtual S2 cancellation, or unrestricted MAX11."
        ),
        "result": "PASS",
        "source_sha256": {
            "analyze_survivor_type_cones.py": hashlib.sha256(
                Path(__file__).with_name("analyze_survivor_type_cones.py").read_bytes()
            ).hexdigest(),
            "exact_zonotope.py": hashlib.sha256(
                Path(__file__).with_name("exact_zonotope.py").read_bytes()
            ).hexdigest(),
        },
    }
    encoded = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(encoded)
    print(json.dumps({
        "schema": report["schema"],
        "full_cell_count": report["full_cell_count"],
        "vertex_counts": report["full_cell_vertex_counts"],
        "smallest_signs": diagnostics["signs"],
        "smallest_nullity": diagnostics["edge_scaling_nullity"],
        "smallest_primitive": diagnostics["primitive_p2_partition"] is not None,
        "smallest_extreme_ray_construction": diagnostics["constructive_extreme_ray_decomposition_hit"],
        "construction_killed": report["construction_killed_by_smallest_cell"],
        "result": report["result"],
    }, sort_keys=True))


if __name__ == "__main__":
    main()
