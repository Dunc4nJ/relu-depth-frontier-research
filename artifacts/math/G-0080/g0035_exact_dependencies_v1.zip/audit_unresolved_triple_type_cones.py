#!/usr/bin/env python3
"""Bounded interior type-cone search for the last seeded three-wall survivor.

The exact 3--5 wall search leaves one three-wall arrangement without either a
constructive ``P^2`` certificate or a rigorous obstruction.  Each of its
eight maximal cells has a two-dimensional nonnegative edge-scaling cone.
This script searches reduced positive projective ratios ``p/q`` of bounded
height between the two exact extreme rays.  At every ratio it reconstructs
the exact summand polytope and applies the sufficient primitive vertex
partition predicate.

Two primitive hits on opposite sides of the parent ratio would construct the
parent cell as a Minkowski sum.  A miss is only finite and predicate-relative;
it is not a ``P^2`` obstruction for the cell or the arrangement.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from collections import Counter
from fractions import Fraction as Q
from pathlib import Path

from analyze_survivor_type_cones import (
    nullspace_basis,
    scaling_cone_rays,
    scaling_system,
    summand_vertex_map,
)
from cone_join_obstruction import affine_rank
from search_one_wall_refinements import primitive_p2_partition
from search_seeded_multiwall_arrangements import (
    all_one_ray_coefficients,
    arrangement_cells,
    certify_cell,
    convex_hull_vertices,
    delta4_positive_control,
    encode_q,
)


HARD_WALLS = (
    (-1, -1, 1, -1, 1, 1, 3),
    (-1, -1, 1, 3, 1, 1, -1),
    (-1, 1, -1, 1, -1, 3, 1),
)


def projective_ratios(bound: int) -> tuple[Q, ...]:
    return tuple(sorted({
        Q(numerator, denominator)
        for numerator in range(1, bound + 1)
        for denominator in range(1, bound + 1)
        if math.gcd(numerator, denominator) == 1
    }))


def audit_cell(cell: tuple[tuple[Q, ...], ...], ratios: tuple[Q, ...]) -> dict[str, object]:
    parent = certify_cell(cell)
    assert parent["status"] == "unresolved"
    assert parent["method"] == "type_cone_has_uncertified_extreme_ray"
    edges, rows = scaling_system(cell)
    basis = nullspace_basis(rows, len(edges))
    rays = scaling_cone_rays(basis)
    assert len(basis) == 2 and len(rays) == 2
    parent_coefficients = all_one_ray_coefficients(rays, 2)
    assert parent_coefficients[0] > 0 and parent_coefficients[1] > 0
    parent_ratio = parent_coefficients[1] / parent_coefficients[0]

    endpoint_records = []
    for ray_index, ray in enumerate(rays):
        summand = convex_hull_vertices(summand_vertex_map(cell, edges, ray))
        certificate = primitive_p2_partition(summand)
        endpoint_records.append({
            "ray_index": ray_index,
            "summand_vertex_count": len(summand),
            "summand_affine_dimension": affine_rank(summand),
            "primitive_partition_hit": certificate is not None,
            "primitive_partition": certificate,
        })

    hits = []
    vertex_count_histogram: Counter[int] = Counter()
    for ratio in ratios:
        scaling = tuple(left + ratio * right for left, right in zip(rays[0], rays[1]))
        summand = convex_hull_vertices(summand_vertex_map(cell, edges, scaling))
        vertex_count_histogram[len(summand)] += 1
        certificate = primitive_p2_partition(summand)
        if certificate is not None:
            hits.append({
                "ratio": encode_q(ratio),
                "summand_vertex_count": len(summand),
                "summand_affine_dimension": affine_rank(summand),
                "primitive_partition": certificate,
            })

    below = [record for record in hits if Q(*record["ratio"]) < parent_ratio]
    above = [record for record in hits if Q(*record["ratio"]) > parent_ratio]
    return {
        "parent_cell_sha256": parent["cell_sha256"],
        "parent_vertex_count": len(cell),
        "parent_affine_dimension": affine_rank(cell),
        "edge_count": len(edges),
        "edge_scaling_nullity": len(basis),
        "extreme_ray_count": len(rays),
        "parent_extreme_ray_coefficients": [encode_q(value) for value in parent_coefficients],
        "parent_projective_ratio_ray1_over_ray0": encode_q(parent_ratio),
        "endpoint_summands": endpoint_records,
        "tested_positive_ratio_count": len(ratios),
        "interior_summand_vertex_count_histogram": dict(sorted(vertex_count_histogram.items())),
        "primitive_partition_hit_count": len(hits),
        "primitive_partition_hits": hits,
        "hit_below_parent_ratio": bool(below),
        "hit_above_parent_ratio": bool(above),
        "two_sided_minkowski_construction_hit": bool(below and above),
    }


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bound", type=int, default=6)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.bound < 1:
        raise SystemExit("--bound must be positive")

    ratios = projective_ratios(args.bound)
    cells = arrangement_cells(HARD_WALLS)
    assert len(cells) == 8
    records = [audit_cell(cell, ratios) for cell in cells]
    hit_count = sum(record["primitive_partition_hit_count"] for record in records)
    construction_count = sum(record["two_sided_minkowski_construction_hit"] for record in records)
    if args.bound == 6:
        assert len(ratios) == 23
        assert hit_count == 0
        assert construction_count == 0

    report = {
        "schema": "g0035-unresolved-triple-interior-type-cone-audit-v1",
        "arithmetic": "fractions.Fraction exact edge scalings and exact zonotope predicates",
        "wall_vertex_order": ["T0", "T1", "T2", "S00", "S10", "S01", "S11"],
        "wall_values": [list(wall) for wall in HARD_WALLS],
        "maximal_cell_count": len(cells),
        "ratio_contract": (
            "all reduced positive p/q with 1 <= p,q <= B, applied projectively as ray0+(p/q)ray1"
        ),
        "bound": args.bound,
        "tested_projective_ratios": [encode_q(ratio) for ratio in ratios],
        "tested_ratio_count_per_cell": len(ratios),
        "total_interior_summand_tests": len(cells) * len(ratios),
        "primitive_partition_hit_count": hit_count,
        "two_sided_minkowski_construction_cell_count": construction_count,
        "cells": records,
        "positive_control": delta4_positive_control(),
        "interpretation": (
            "No tested interior type-cone summand has the sufficient primitive vertex-partition "
            "certificate. Therefore the bounded scan supplies no two-sided Minkowski construction "
            "for any of the eight cells."
        ),
        "no_claim": (
            "This finite ratio miss is not a P2 obstruction. Ratios of larger height, arbitrary "
            "real ratios, primitive P2 representations using interior zonotope vertices, other "
            "Minkowski decompositions, different walls, virtual S2 cancellation, and unrestricted "
            "MAX11 remain open."
        ),
        "result": "PASS",
        "source_sha256": {
            "analyze_survivor_type_cones.py": sha256(Path(__file__).with_name("analyze_survivor_type_cones.py")),
            "exact_zonotope.py": sha256(Path(__file__).with_name("exact_zonotope.py")),
            "search_seeded_multiwall_arrangements.py": sha256(Path(__file__).with_name("search_seeded_multiwall_arrangements.py")),
        },
    }
    encoded = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(encoded)
    print(json.dumps({
        "schema": report["schema"],
        "cells": len(cells),
        "ratios_per_cell": len(ratios),
        "total_tests": report["total_interior_summand_tests"],
        "primitive_hits": hit_count,
        "two_sided_construction_cells": construction_count,
        "positive_control": report["positive_control"]["all_cells_constructively_certified_p2"],
        "result": report["result"],
    }, sort_keys=True))


if __name__ == "__main__":
    main()
