#!/usr/bin/env python3
"""Exact bounded search for one-wall P^2 refinements of Delta_2 * square.

The wall is represented by its affine values on the seven vertices of
``P = Delta_2 * [0,1]^2``.  Those values obey the one square relation

    b_00 + b_11 = b_10 + b_01.

We exhaust primitive integer value vectors in ``[-B,B]`` having a zero entry
(the wall passes through an existing vertex), quotient by the exact symmetry
``S_3 x D_4`` and global sign, cut every edge exactly, and seek a *sufficient*
primitive P^2 certificate for both children.  A certificate partitions all
child vertices into the vertex sets of two low-dimensional zonotopes: points,
segments, centrally symmetric polygons, or affine 3-cubes.

A hit is an exact construction.  A miss is bounded to this wall range and
this sufficient certificate predicate; it is not an obstruction to arbitrary
P^2 decompositions of the children.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
from fractions import Fraction as Q
from pathlib import Path
from typing import Iterable, Sequence

from cone_join_obstruction import affine_rank, join_edges_and_triangles, join_vertices
from exact_zonotope import candidate_zonotope_masks as exact_candidate_zonotope_masks


Vector = tuple[Q, ...]


def cut_vertices(vertices: Sequence[Vector], edges: Iterable[tuple[int, int]], values: Sequence[int], side: int) -> tuple[Vector, ...]:
    """Vertices of P intersect {side*f >= 0}, from vertices and crossed edges."""
    output: set[Vector] = {
        vertex for vertex, value in zip(vertices, values) if side * value >= 0
    }
    for left_index, right_index in edges:
        left_value = values[left_index]
        right_value = values[right_index]
        if left_value * right_value >= 0:
            continue
        left = vertices[left_index]
        right = vertices[right_index]
        denominator = Q(right_value - left_value)
        # (right_value * left - left_value * right)/(right_value-left_value)
        intersection = tuple(
            (Q(right_value) * x - Q(left_value) * y) / denominator
            for x, y in zip(left, right)
        )
        output.add(intersection)
    return tuple(sorted(output))


def candidate_masks(vertices: Sequence[Vector]) -> dict[int, tuple[int, str]]:
    labels = {
        0: "point",
        1: "segment",
        2: "centrally-symmetric-polygon",
        3: "exact-zonotope-3d",
        4: "exact-zonotope-4d",
    }
    return {
        mask: (dimension, labels.get(dimension, f"exact-zonotope-{dimension}d"))
        for mask, dimension in exact_candidate_zonotope_masks(vertices).items()
    }


def primitive_p2_partition(vertices: Sequence[Vector]) -> dict[str, object] | None:
    full_dimension = affine_rank(vertices)
    count = len(vertices)
    if full_dimension <= 0:
        return None
    masks = candidate_masks(vertices)
    full_mask = (1 << count) - 1
    for mask, (left_dimension, left_type) in masks.items():
        if not (mask & 1) or mask == full_mask:
            continue
        right = masks.get(full_mask ^ mask)
        if right is None:
            continue
        right_dimension, right_type = right
        if left_dimension + right_dimension + 1 < full_dimension:
            continue
        return {
            "left_indices": [index for index in range(count) if mask & (1 << index)],
            "right_indices": [index for index in range(count) if not mask & (1 << index)],
            "left_dimension": left_dimension,
            "right_dimension": right_dimension,
            "left_type": left_type,
            "right_type": right_type,
        }
    return None


def square_symmetries() -> tuple[tuple[int, ...], ...]:
    bits = ((0, 0), (1, 0), (0, 1), (1, 1))
    index = {point: position for position, point in enumerate(bits)}
    permutations: set[tuple[int, ...]] = set()
    for swap in (False, True):
        for flip0, flip1 in itertools.product((False, True), repeat=2):
            transformed = []
            for x, y in bits:
                if swap:
                    x, y = y, x
                if flip0:
                    x = 1 - x
                if flip1:
                    y = 1 - y
                transformed.append(index[(x, y)])
            permutations.add(tuple(transformed))
    assert len(permutations) == 8
    return tuple(sorted(permutations))


def canonical_wall(values: Sequence[int]) -> tuple[int, ...]:
    triangle = values[:3]
    square = values[3:]
    images: list[tuple[int, ...]] = []
    for triangle_permutation in itertools.permutations(range(3)):
        for square_permutation in square_symmetries():
            transformed = tuple(triangle[index] for index in triangle_permutation) + tuple(
                square[index] for index in square_permutation
            )
            images.extend((transformed, tuple(-value for value in transformed)))
    return min(images)


def primitive_integer_wall(values: Sequence[int]) -> bool:
    nonzero = [abs(value) for value in values if value]
    return bool(nonzero) and math.gcd(*nonzero) == 1


def enumerate_walls(bound: int) -> tuple[tuple[int, ...], ...]:
    representatives: set[tuple[int, ...]] = set()
    value_range = range(-bound, bound + 1)
    for triangle in itertools.product(value_range, repeat=3):
        for b00, b10, b01 in itertools.product(value_range, repeat=3):
            b11 = b10 + b01 - b00
            if not -bound <= b11 <= bound:
                continue
            values = (*triangle, b00, b10, b01, b11)
            if 0 not in values or min(values) >= 0 or max(values) <= 0:
                continue
            if not primitive_integer_wall(values):
                continue
            representatives.add(canonical_wall(values))
    return tuple(sorted(representatives))


def encode_vertex(vertex: Vector) -> list[list[int]]:
    return [[value.numerator, value.denominator] for value in vertex]


def analyze_wall(values: Sequence[int]) -> dict[str, object]:
    vertices = join_vertices(2)
    edges, _triangles = join_edges_and_triangles(2)
    children = []
    for side in (-1, 1):
        child = cut_vertices(vertices, edges, values, side)
        certificate = primitive_p2_partition(child)
        children.append({
            "side": side,
            "vertex_count": len(child),
            "affine_dimension": affine_rank(child),
            "primitive_p2_certificate": certificate,
            "vertices": [encode_vertex(vertex) for vertex in child] if certificate else None,
        })
    return {
        "values": list(values),
        "children": children,
        "both_children_certified": all(child["primitive_p2_certificate"] is not None for child in children),
    }


def positive_control() -> dict[str, object]:
    vertices = join_vertices(1)
    certificate = primitive_p2_partition(vertices)
    assert certificate is not None
    # Move one square vertex off the parallelogram.  The original partition
    # must cease to certify, while the cell remains full dimensional.
    mutant = list(vertices)
    changed = list(mutant[-1])
    changed[1] += Q(1, 7)
    mutant[-1] = tuple(changed)
    assert affine_rank(tuple(mutant)) == 4
    assert primitive_p2_partition(tuple(mutant)) is None
    return {
        "cell": "Delta_1 * square",
        "vertex_count": len(vertices),
        "affine_dimension": affine_rank(vertices),
        "certificate": certificate,
        "mutation": "add 1/7 to one square-vertex coordinate",
        "mutation_rejected": True,
    }


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bound", type=int, default=2)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.bound < 1:
        raise SystemExit("--bound must be positive")

    control = positive_control()
    walls = enumerate_walls(args.bound)
    hits: list[dict[str, object]] = []
    child_certificate_histogram: dict[str, int] = {}
    for values in walls:
        analysis = analyze_wall(values)
        certified = sum(child["primitive_p2_certificate"] is not None for child in analysis["children"])
        child_certificate_histogram[str(certified)] = child_certificate_histogram.get(str(certified), 0) + 1
        if analysis["both_children_certified"]:
            hits.append(analysis)

    project = Path(__file__).resolve().parents[3]
    report = {
        "arithmetic": "fractions.Fraction",
        "bound": args.bound,
        "wall_contract": (
            "primitive integer affine values in [-B,B] on the seven join vertices; at least one "
            "zero; both signs; square relation b00+b11=b10+b01; quotient by S3 x D4 and global sign"
        ),
        "wall_representative_count": len(walls),
        "child_certificate_histogram": child_certificate_histogram,
        "hit_count": len(hits),
        "hits": hits,
        "positive_control": control,
        "no_claim": (
            "A zero hit count excludes only this finite wall-value range and the sufficient "
            "primitive zonotope-partition predicate. A child could be in P2 through a nontrivial "
            "Minkowski sum or a zonotope type not recognized here; walls not through old vertices "
            "and larger rational ratios are outside the census."
        ),
        "result": "PASS",
        "schema": "g0035-one-wall-refinement-search-v1",
        "source_sha256": {
            "G-0031/README.md": sha256(project / "artifacts/math/G-0031/README.md"),
            "cone_join_obstruction.py": sha256(Path(__file__).with_name("cone_join_obstruction.py")),
            "exact_zonotope.py": sha256(Path(__file__).with_name("exact_zonotope.py")),
        },
    }
    encoded = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(encoded)
    print(json.dumps(report, sort_keys=True))


if __name__ == "__main__":
    main()
