#!/usr/bin/env python3
"""Exact Minkowski type-cone audit for the three off-vertex witnesses.

The off-vertex sign classifier leaves three symmetry classes.  Its displayed
wall witnesses have children whose edge-scaling spaces have nullity two or
three, so primitive failure does not decide membership in P^2.  This script
computes the extreme rays of those nonnegative edge-scaling cones exactly,
reconstructs the corresponding Minkowski summand polytopes, and applies the
sufficient primitive zonotope-partition predicate to every ray summand.

This is an exploratory decomposition audit, not a complete P^2 decision:
primitive blocks may lie in the interior of a type cone, and failure of the
vertex-partition predicate is not a primitive obstruction by itself.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
from fractions import Fraction as Q
from pathlib import Path
from typing import Sequence

import z3

from cone_join_obstruction import affine_rank, join_edges_and_triangles, join_vertices, matrix_rank
from exact_zonotope import affine_coordinates, face_lattice, null_vector
from search_one_wall_refinements import cut_vertices, primitive_p2_partition


Vector = tuple[Q, ...]
WITNESSES = (
    (-1, -1, -1, 1, 1, 1, 1),
    (-1, -1, 1, -1, 1, 1, 3),
    (-1, -1, 1, 1, 1, 1, 1),
)


def sub(left: Sequence[Q], right: Sequence[Q]) -> Vector:
    return tuple(a - b for a, b in zip(left, right))


def add(left: Sequence[Q], right: Sequence[Q]) -> Vector:
    return tuple(a + b for a, b in zip(left, right))


def scale(coefficient: Q, vector: Sequence[Q]) -> Vector:
    return tuple(coefficient * value for value in vector)


def scaling_system(points: Sequence[Vector]) -> tuple[tuple[frozenset[int], ...], tuple[Vector, ...]]:
    """Return ordered polytope edges and the exact two-face closure rows."""
    coordinates = affine_coordinates(points)
    faces = face_lattice(coordinates)
    edges = tuple(sorted(
        (
            face
            for face in faces
            if len(face) == 2
            and affine_rank(tuple(coordinates[index] for index in face)) == 1
        ),
        key=lambda edge: tuple(edge),
    ))
    edge_index = {edge: index for index, edge in enumerate(edges)}
    two_faces = tuple(
        face
        for face in faces
        if len(face) >= 3
        and affine_rank(tuple(coordinates[index] for index in face)) == 2
    )
    rows: list[Vector] = []
    for face in two_faces:
        induced = {
            vertex: sorted(
                next(iter(edge - {vertex}))
                for edge in edges
                if vertex in edge and edge.issubset(face)
            )
            for vertex in face
        }
        assert all(len(neighbors) == 2 for neighbors in induced.values())
        start = min(face)
        previous = None
        current = start
        cycle = [start]
        while True:
            following = next(neighbor for neighbor in induced[current] if neighbor != previous)
            if following == start:
                break
            assert following not in cycle
            cycle.append(following)
            previous, current = current, following
        for coordinate in range(len(coordinates[0])):
            row = [Q(0)] * len(edges)
            for position, vertex in enumerate(cycle):
                following = cycle[(position + 1) % len(cycle)]
                edge = frozenset((vertex, following))
                row[edge_index[edge]] += (
                    coordinates[following][coordinate] - coordinates[vertex][coordinate]
                )
            rows.append(tuple(row))
    return edges, tuple(rows)


def nullspace_basis(rows: Sequence[Sequence[Q]], column_count: int) -> tuple[Vector, ...]:
    matrix = [list(map(Q, row)) for row in rows]
    pivot_columns: list[int] = []
    pivot_row = 0
    for column in range(column_count):
        pivot = next(
            (row for row in range(pivot_row, len(matrix)) if matrix[row][column]),
            None,
        )
        if pivot is None:
            continue
        matrix[pivot_row], matrix[pivot] = matrix[pivot], matrix[pivot_row]
        pivot_value = matrix[pivot_row][column]
        matrix[pivot_row] = [value / pivot_value for value in matrix[pivot_row]]
        for row in range(len(matrix)):
            if row == pivot_row or not matrix[row][column]:
                continue
            coefficient = matrix[row][column]
            matrix[row] = [
                value - coefficient * pivot_entry
                for value, pivot_entry in zip(matrix[row], matrix[pivot_row])
            ]
        pivot_columns.append(column)
        pivot_row += 1
        if pivot_row == len(matrix):
            break
    free_columns = [column for column in range(column_count) if column not in pivot_columns]
    basis = []
    for free in free_columns:
        vector = [Q(0)] * column_count
        vector[free] = Q(1)
        for row, pivot in reversed(tuple(enumerate(pivot_columns))):
            vector[pivot] = -sum(
                (matrix[row][column] * vector[column] for column in free_columns),
                Q(0),
            )
        basis.append(tuple(vector))
    assert len(basis) == column_count - matrix_rank(rows)
    return tuple(basis)


def normalize_nonnegative(vector: Sequence[Q]) -> Vector:
    denominator_lcm = math.lcm(*(value.denominator for value in vector))
    integers = [value.numerator * (denominator_lcm // value.denominator) for value in vector]
    divisor = math.gcd(*(abs(value) for value in integers if value))
    normalized = tuple(Q(value // divisor) for value in integers)
    assert all(value >= 0 for value in normalized) and any(normalized)
    return normalized


def scaling_cone_rays(basis: Sequence[Vector]) -> tuple[Vector, ...]:
    """Extreme rays of ``span(basis) intersect R_+^E`` for nullity <= 3."""
    nullity = len(basis)
    if not 1 <= nullity <= 3:
        raise ValueError("this audit supports nullity one through three")
    edge_count = len(basis[0])
    inequalities = tuple(
        tuple(basis[coordinate][edge] for coordinate in range(nullity))
        for edge in range(edge_count)
    )
    parameter_rays: list[Vector] = []
    if nullity == 1:
        parameter_rays = [(Q(1),), (Q(-1),)]
    else:
        for active in itertools.combinations(inequalities, nullity - 1):
            if matrix_rank(active) != nullity - 1:
                continue
            direction = null_vector(active)
            assert direction is not None
            parameter_rays.extend((direction, scale(Q(-1), direction)))
    rays = set()
    for parameters in parameter_rays:
        scaling = tuple(
            sum(
                (parameters[coordinate] * basis[coordinate][edge] for coordinate in range(nullity)),
                Q(0),
            )
            for edge in range(edge_count)
        )
        if any(value < 0 for value in scaling) or not any(scaling):
            continue
        rays.add(normalize_nonnegative(scaling))
    output = tuple(sorted(rays))
    assert output
    return output


def summand_vertex_map(points: Sequence[Vector], edges: Sequence[frozenset[int]], scaling: Sequence[Q]) -> tuple[Vector, ...]:
    """Integrate an edge-scaling ray at every vertex of the parent polytope."""
    edge_scaling = {edge: value for edge, value in zip(edges, scaling)}
    zero = tuple(Q(0) for _ in points[0])
    images: list[Vector | None] = [None] * len(points)
    images[0] = zero
    progress = True
    while progress:
        progress = False
        for edge, coefficient in edge_scaling.items():
            left, right = sorted(edge)
            difference = scale(coefficient, sub(points[right], points[left]))
            if images[left] is not None:
                candidate = add(images[left], difference)
                if images[right] is None:
                    images[right] = candidate
                    progress = True
                else:
                    assert images[right] == candidate
            elif images[right] is not None:
                images[left] = sub(images[right], difference)
                progress = True
    assert all(image is not None for image in images)
    return tuple(image for image in images if image is not None)


def summand_vertices(points: Sequence[Vector], edges: Sequence[frozenset[int]], scaling: Sequence[Q]) -> tuple[Vector, ...]:
    """Distinct vertices of the summand reconstructed from an edge-scaling ray."""
    return tuple(sorted(set(summand_vertex_map(points, edges, scaling))))


def all_one_decomposition(rays: Sequence[Vector]) -> list[str]:
    coefficients = [z3.Real(f"coefficient_{index}") for index in range(len(rays))]
    solver = z3.Solver()
    solver.add(*(coefficient >= 0 for coefficient in coefficients))
    for edge in range(len(rays[0])):
        solver.add(
            z3.Sum(*[
                coefficient * z3.RealVal(
                    f"{ray[edge].numerator}/{ray[edge].denominator}"
                )
                for coefficient, ray in zip(coefficients, rays)
            ])
            == 1
        )
    assert solver.check() == z3.sat
    model = solver.model()
    return [str(model.eval(coefficient, model_completion=True)) for coefficient in coefficients]


def analyze_child(points: Sequence[Vector]) -> dict[str, object]:
    edges, rows = scaling_system(points)
    basis = nullspace_basis(rows, len(edges))
    rays = scaling_cone_rays(basis)
    ray_records = []
    for ray in rays:
        summand = summand_vertices(points, edges, ray)
        certificate = primitive_p2_partition(summand)
        ray_records.append({
            "zero_edge_count": sum(value == 0 for value in ray),
            "summand_vertex_count": len(summand),
            "summand_affine_dimension": affine_rank(summand),
            "primitive_p2_partition": certificate,
            "primitive_p2_certified": certificate is not None,
        })
    return {
        "vertex_count": len(points),
        "affine_dimension": affine_rank(points),
        "edge_count": len(edges),
        "edge_scaling_rank": matrix_rank(rows),
        "edge_scaling_nullity": len(basis),
        "scaling_cone_extreme_ray_count": len(rays),
        "all_one_extreme_ray_coefficients": all_one_decomposition(rays),
        "extreme_ray_summands": ray_records,
        "all_extreme_ray_summands_primitive_p2_certified": all(
            record["primitive_p2_certified"] for record in ray_records
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    vertices = join_vertices(2)
    original_edges, _triangles = join_edges_and_triangles(2)
    walls = []
    construction_count = 0
    for values in WITNESSES:
        children = []
        for side in (-1, 1):
            child = cut_vertices(vertices, original_edges, values, side)
            analysis = analyze_child(child)
            if analysis["all_extreme_ray_summands_primitive_p2_certified"]:
                construction_count += 1
            children.append({"side": side, **analysis})
        walls.append({"wall_values": list(values), "children": children})
    report = {
        "schema": "g0035-off-vertex-survivor-type-cones-v1",
        "arithmetic": "fractions.Fraction exact edge scaling plus Z3 exact rational coefficients",
        "wall_count": len(walls),
        "child_count": 2 * len(walls),
        "children_with_constructive_extreme_ray_certificate": construction_count,
        "walls": walls,
        "interpretation": (
            "A child is constructively in P2 when its all-one edge scaling is a nonnegative "
            "sum of extreme-ray scalings and every reconstructed ray summand has an explicit "
            "primitive zonotope-vertex partition."
        ),
        "no_claim": (
            "Failure of the sufficient primitive vertex-partition predicate on a ray summand "
            "does not prove that summand or child is outside P2. This finite audit covers only "
            "the three displayed wall ratios, not every ratio in their sign orthants, multiple "
            "walls, virtual S2 cancellation, or unrestricted MAX11."
        ),
        "source_sha256": {
            "classify_off_vertex_walls.py": hashlib.sha256(
                Path(__file__).with_name("classify_off_vertex_walls.py").read_bytes()
            ).hexdigest(),
            "exact_zonotope.py": hashlib.sha256(
                Path(__file__).with_name("exact_zonotope.py").read_bytes()
            ).hexdigest(),
        },
        "result": "PASS",
        "z3_version": z3.get_version_string(),
    }
    encoded = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(encoded)
    print(json.dumps({
        "schema": report["schema"],
        "wall_count": report["wall_count"],
        "child_count": report["child_count"],
        "children_with_constructive_extreme_ray_certificate": construction_count,
        "result": report["result"],
    }, sort_keys=True))


if __name__ == "__main__":
    main()
