#!/usr/bin/env python3
"""Exact obstruction audit for the bounded G-0035 one-wall census.

For each symmetry-reduced wall, this script seeks one child satisfying BOTH:

1. its exact edge-scaling space has nullity one, so every Minkowski summand
   is homothetic or a point;
2. Z3 exact rational linear arithmetic proves that no two centrally symmetric
   convex subsets can cover its vertices.

Together these imply that child is not in P^2.  One such child kills the
proposed two-cell P^2 subdivision.  The conclusion remains bounded to the
enumerated wall-value contract.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from fractions import Fraction as Q
from pathlib import Path
from typing import Sequence

import z3

from cone_join_obstruction import join_edges_and_triangles, join_membership, join_vertices, z3_q
from exact_zonotope import edge_scaling_space
from search_one_wall_refinements import cut_vertices, enumerate_walls


Vector = tuple[Q, ...]


def wall_coefficients(values: Sequence[int]) -> tuple[Q, ...]:
    """Return c,ax1,ax2,ay1,ay2,at for the affine wall function."""
    if len(values) != 7:
        raise ValueError("seven vertex values required")
    a0, a1, a2, b00, b10, b01, b11 = map(Q, values)
    assert b00 + b11 == b10 + b01
    return (a0, a1 - a0, a2 - a0, b10 - b00, b01 - b00, b00 - a0)


def wall_value(point: Sequence[z3.ArithRef], coefficients: Sequence[Q]) -> z3.ArithRef:
    constant, ax1, ax2, ay1, ay2, at = coefficients
    x1, x2, y1, y2, t = point
    return (
        z3_q(constant)
        + z3_q(ax1) * x1
        + z3_q(ax2) * x2
        + z3_q(ay1) * y1
        + z3_q(ay2) * y2
        + z3_q(at) * t
    )


def central_cover_query(
    vertices: Sequence[Vector],
    values: Sequence[int],
    side: int,
    center_count: int = 2,
    want_proof: bool = False,
) -> tuple[z3.CheckSatResult, str | None, dict[str, object] | None]:
    coefficients = wall_coefficients(values)
    centers = [
        [z3.Real(f"c_{side}_{center_count}_{group}_{coordinate}") for coordinate in range(5)]
        for group in range(center_count)
    ]
    colors = [z3.Int(f"color_{side}_{center_count}_{index}") for index in range(len(vertices))]
    solver = z3.Solver()
    solver.add(*(z3.And(color >= 0, color < center_count) for color in colors))
    for vertex_index, vertex in enumerate(vertices):
        for group in range(center_count):
            reflection = [
                2 * centers[group][coordinate] - z3_q(vertex[coordinate])
                for coordinate in range(5)
            ]
            membership = z3.And(
                join_membership(reflection, 2),
                side * wall_value(reflection, coefficients) >= 0,
            )
            solver.add(z3.Implies(colors[vertex_index] == group, membership))
    result = solver.check()
    proof = str(solver.proof()) if want_proof and result == z3.unsat else None
    model_payload = None
    if result == z3.sat:
        model = solver.model()
        model_payload = {
            "colors": [model.eval(color).as_long() for color in colors],
            "centers": [
                [str(model.eval(value, model_completion=True)) for value in center]
                for center in centers
            ],
        }
    return result, proof, model_payload


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bound", type=int, default=2)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    z3.set_param(proof=True)
    vertices = join_vertices(2)
    edges, _triangles = join_edges_and_triangles(2)
    walls = enumerate_walls(args.bound)
    killed: list[dict[str, object]] = []
    survivors: list[dict[str, object]] = []
    scaling_histogram: dict[str, int] = {}
    cover_histogram: dict[str, int] = {}
    proof_sample: dict[str, object] | None = None

    for wall_index, values in enumerate(walls):
        child_records = []
        wall_killer = None
        for side in (-1, 1):
            child = cut_vertices(vertices, edges, values, side)
            scaling = edge_scaling_space(child)
            nullity = int(scaling["edge_scaling_nullity"])
            scaling_histogram[str(nullity)] = scaling_histogram.get(str(nullity), 0) + 1
            cover_result = None
            if scaling["minkowski_indecomposable"]:
                result, proof, model = central_cover_query(
                    child, values, side, want_proof=proof_sample is None
                )
                cover_result = str(result)
                cover_histogram[cover_result] = cover_histogram.get(cover_result, 0) + 1
                if result == z3.unsat and wall_killer is None:
                    wall_killer = {
                        "side": side,
                        "vertex_count": len(child),
                        "edge_scaling": scaling,
                        "central_cover": cover_result,
                    }
                    if proof_sample is None:
                        assert proof is not None
                        proof_sample = {
                            "wall_index": wall_index,
                            "wall_values": list(values),
                            "side": side,
                            "proof_chars": len(proof),
                            "proof_sha256": hashlib.sha256(proof.encode()).hexdigest(),
                        }
                elif result == z3.sat:
                    child_records.append({
                        "side": side,
                        "vertex_count": len(child),
                        "edge_scaling": scaling,
                        "central_cover": cover_result,
                        "cover_model": model,
                    })
            if wall_killer is not None:
                break
            child_records.append({
                "side": side,
                "vertex_count": len(child),
                "edge_scaling": scaling,
                "central_cover": cover_result,
            })
        if wall_killer is not None:
            killed.append({"wall_values": list(values), "killer": wall_killer})
        else:
            survivors.append({"wall_values": list(values), "children": child_records})

    # Potency: on the sampled killed child, one point-center per vertex must
    # make the same reflection-membership encoding satisfiable.
    assert killed
    sample_values = tuple(killed[0]["wall_values"])
    sample_side = int(killed[0]["killer"]["side"])
    sample_child = cut_vertices(vertices, edges, sample_values, sample_side)
    many_result, _, many_model = central_cover_query(
        sample_child, sample_values, sample_side, center_count=len(sample_child)
    )
    assert many_result == z3.sat and many_model is not None

    report = {
        "arithmetic": "fractions.Fraction plus Z3 exact QF_LIRA over rationals",
        "bound": args.bound,
        "wall_representative_count": len(walls),
        "killed_wall_count": len(killed),
        "survivor_count": len(survivors),
        "survivors": survivors,
        "edge_scaling_nullity_histogram_for_examined_children": scaling_histogram,
        "two_center_cover_histogram_for_indecomposable_children": cover_histogram,
        "unsat_proof_sample": proof_sample,
        "potency": {
            "sample_child_vertex_count": len(sample_child),
            "one_center_per_vertex": str(many_result),
        },
        "no_claim": (
            "The audit proves a bounded no-go only for the symmetry-reduced primitive integer "
            "wall values in [-B,B] that pass through an old vertex. It says nothing about "
            "off-vertex walls, larger rational ratios, multiple new walls, arbitrary P2 "
            "subdivisions, virtual S2 cancellation, or unrestricted MAX11."
        ),
        "result": "PASS",
        "schema": "g0035-one-wall-obstruction-audit-v1",
        "source_sha256": {
            "cone_join_obstruction.py": hashlib.sha256(
                Path(__file__).with_name("cone_join_obstruction.py").read_bytes()
            ).hexdigest(),
            "exact_zonotope.py": hashlib.sha256(
                Path(__file__).with_name("exact_zonotope.py").read_bytes()
            ).hexdigest(),
            "search_one_wall_refinements.py": hashlib.sha256(
                Path(__file__).with_name("search_one_wall_refinements.py").read_bytes()
            ).hexdigest(),
        },
        "z3_version": z3.get_version_string(),
    }
    encoded = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(encoded)
    print(json.dumps({
        "schema": report["schema"],
        "bound": args.bound,
        "wall_representative_count": len(walls),
        "killed_wall_count": len(killed),
        "survivor_count": len(survivors),
        "scaling_histogram": scaling_histogram,
        "cover_histogram": cover_histogram,
        "potency": report["potency"],
        "result": "PASS",
    }, sort_keys=True))


if __name__ == "__main__":
    main()
