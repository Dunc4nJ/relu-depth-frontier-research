"""Small exact polyhedral predicates used by the G-0035 searches.

The central theorem used here is the standard characterization: a convex
polytope is a zonotope iff each of its two-dimensional faces is centrally
symmetric.  All vertices and supporting hyperplanes are handled over
``fractions.Fraction``.
"""

from __future__ import annotations

import itertools
from functools import lru_cache
from fractions import Fraction as Q
from typing import Iterable, Sequence

from cone_join_obstruction import affine_rank, matrix_rank


Vector = tuple[Q, ...]


def add(a: Sequence[Q], b: Sequence[Q]) -> Vector:
    return tuple(x + y for x, y in zip(a, b))


def sub(a: Sequence[Q], b: Sequence[Q]) -> Vector:
    return tuple(x - y for x, y in zip(a, b))


def scale(c: Q, a: Sequence[Q]) -> Vector:
    return tuple(c * x for x in a)


def dot(a: Sequence[Q], b: Sequence[Q]) -> Q:
    return sum((x * y for x, y in zip(a, b)), Q(0))


def solve_square(rows: Sequence[Sequence[Q]], rhs: Sequence[Q]) -> Vector | None:
    n = len(rows)
    augmented = [list(map(Q, row)) + [Q(value)] for row, value in zip(rows, rhs)]
    if len(rhs) != n or any(len(row) != n + 1 for row in augmented):
        raise ValueError("square system required")
    for column in range(n):
        pivot = next((row for row in range(column, n) if augmented[row][column]), None)
        if pivot is None:
            return None
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]
        pivot_value = augmented[column][column]
        augmented[column] = [value / pivot_value for value in augmented[column]]
        for row in range(n):
            if row == column or not augmented[row][column]:
                continue
            coefficient = augmented[row][column]
            augmented[row] = [
                value - coefficient * pivot_entry
                for value, pivot_entry in zip(augmented[row], augmented[column])
            ]
    return tuple(row[-1] for row in augmented)


def null_vector(rows: Sequence[Sequence[Q]]) -> Vector | None:
    """Return one nonzero null vector when nullity is exactly one."""
    if not rows:
        return None
    matrix = [list(map(Q, row)) for row in rows]
    nrows = len(matrix)
    ncols = len(matrix[0])
    pivot_columns: list[int] = []
    pivot_row = 0
    for column in range(ncols):
        pivot = next((row for row in range(pivot_row, nrows) if matrix[row][column]), None)
        if pivot is None:
            continue
        matrix[pivot_row], matrix[pivot] = matrix[pivot], matrix[pivot_row]
        pivot_value = matrix[pivot_row][column]
        matrix[pivot_row] = [value / pivot_value for value in matrix[pivot_row]]
        for row in range(nrows):
            if row == pivot_row or not matrix[row][column]:
                continue
            coefficient = matrix[row][column]
            matrix[row] = [
                value - coefficient * pivot_entry
                for value, pivot_entry in zip(matrix[row], matrix[pivot_row])
            ]
        pivot_columns.append(column)
        pivot_row += 1
        if pivot_row == nrows:
            break
    free_columns = [column for column in range(ncols) if column not in pivot_columns]
    if len(free_columns) != 1:
        return None
    free = free_columns[0]
    vector = [Q(0)] * ncols
    vector[free] = Q(1)
    for row, pivot in reversed(tuple(enumerate(pivot_columns))):
        vector[pivot] = -sum(
            (matrix[row][column] * vector[column] for column in free_columns), Q(0)
        )
    assert all(dot(row, vector) == 0 for row in rows)
    return tuple(vector)


def affine_coordinates(points: Sequence[Vector]) -> tuple[Vector, ...]:
    """Move an affine d-polytope to exact full-dimensional coordinates Q^d."""
    dimension = affine_rank(points)
    if dimension == 0:
        return tuple((Q(0),) for _ in points)
    origin = points[0]
    basis: list[Vector] = []
    for point in points[1:]:
        difference = sub(point, origin)
        if matrix_rank((*basis, difference)) > len(basis):
            basis.append(difference)
        if len(basis) == dimension:
            break
    ambient_dimension = len(origin)
    coordinate_indices = next(
        indices
        for indices in itertools.combinations(range(ambient_dimension), dimension)
        if matrix_rank(
            tuple(tuple(basis[column][coordinate] for column in range(dimension)) for coordinate in indices)
        ) == dimension
    )
    rows = tuple(
        tuple(basis[column][coordinate] for column in range(dimension))
        for coordinate in coordinate_indices
    )
    coordinates: list[Vector] = []
    for point in points:
        difference = sub(point, origin)
        rhs = tuple(difference[coordinate] for coordinate in coordinate_indices)
        coefficients = solve_square(rows, rhs)
        assert coefficients is not None
        reconstructed = tuple(
            sum((coefficients[column] * basis[column][coordinate] for column in range(dimension)), Q(0))
            for coordinate in range(ambient_dimension)
        )
        assert reconstructed == difference
        coordinates.append(coefficients)
    return tuple(coordinates)


def centrally_symmetric(points: Sequence[Vector]) -> bool:
    if not points:
        return False
    center = tuple(
        sum((point[coordinate] for point in points), Q(0)) / len(points)
        for coordinate in range(len(points[0]))
    )
    point_set = set(points)
    return all(sub(scale(Q(2), center), point) in point_set for point in points)


def facets(points: Sequence[Vector]) -> tuple[frozenset[int], ...]:
    """Enumerate every facet vertex set of a full-dimensional rational polytope."""
    dimension = len(points[0])
    assert affine_rank(points) == dimension
    output: set[frozenset[int]] = set()
    for subset in itertools.combinations(range(len(points)), dimension):
        selected = tuple(points[index] for index in subset)
        if affine_rank(selected) != dimension - 1:
            continue
        kernel = null_vector(tuple((*point, Q(1)) for point in selected))
        if kernel is None:
            continue
        values = tuple(dot((*point, Q(1)), kernel) for point in points)
        if not (all(value >= 0 for value in values) or all(value <= 0 for value in values)):
            continue
        face = frozenset(index for index, value in enumerate(values) if value == 0)
        if affine_rank(tuple(points[index] for index in face)) == dimension - 1:
            output.add(face)
    return tuple(sorted(output, key=lambda face: (len(face), tuple(face))))


def face_lattice(points: Sequence[Vector]) -> tuple[frozenset[int], ...]:
    """All nonempty faces as intersections of exact facets, including P."""
    facet_sets = facets(points)
    faces: set[frozenset[int]] = {frozenset(range(len(points)))}
    for facet in facet_sets:
        additions = {face & facet for face in faces if face & facet}
        faces.update(additions)
    return tuple(sorted(faces, key=lambda face: (len(face), tuple(face))))


def two_faces(points: Sequence[Vector]) -> tuple[frozenset[int], ...]:
    dimension = len(points[0])
    if dimension == 2:
        return (frozenset(range(len(points))),)
    faces = face_lattice(points)
    output = {
        face
        for face in faces
        if len(face) >= 3 and affine_rank(tuple(points[index] for index in face)) == 2
    }
    return tuple(sorted(output, key=lambda face: (len(face), tuple(face))))


def edge_triangle_connectivity(points: Sequence[Vector]) -> dict[str, int | bool]:
    """Connectivity of polytope edges under common triangular 2-faces."""
    coordinates = affine_coordinates(points)
    faces = face_lattice(coordinates)
    edges = {
        face
        for face in faces
        if len(face) == 2 and affine_rank(tuple(coordinates[index] for index in face)) == 1
    }
    triangles = {
        face
        for face in faces
        if len(face) == 3 and affine_rank(tuple(coordinates[index] for index in face)) == 2
    }
    adjacency = {edge: set() for edge in edges}
    for triangle in triangles:
        triangle_edges = {edge for edge in edges if edge.issubset(triangle)}
        assert len(triangle_edges) == 3
        for edge in triangle_edges:
            adjacency[edge].update(triangle_edges - {edge})
    if not edges:
        return {
            "edge_count": 0,
            "triangular_face_count": len(triangles),
            "reached_edge_count": 0,
            "edge_triangle_graph_connected": False,
        }
    start = next(iter(edges))
    reached = {start}
    frontier = [start]
    while frontier:
        edge = frontier.pop()
        for other in adjacency[edge]:
            if other not in reached:
                reached.add(other)
                frontier.append(other)
    return {
        "edge_count": len(edges),
        "triangular_face_count": len(triangles),
        "reached_edge_count": len(reached),
        "edge_triangle_graph_connected": reached == edges,
    }


def edge_scaling_space(points: Sequence[Vector]) -> dict[str, int | bool]:
    """Exact linear space of edge scalings compatible on every 2-face.

    A Minkowski summand assigns a nonnegative scalar to each edge direction.
    Around every polygonal two-face, the scaled oriented edge vectors must
    close.  If the resulting linear nullspace is one-dimensional, the all-one
    scaling spans it and every summand is homothetic (or a point).
    """
    coordinates = affine_coordinates(points)
    faces = face_lattice(coordinates)
    edges = tuple(sorted(
        (
            face for face in faces
            if len(face) == 2 and affine_rank(tuple(coordinates[index] for index in face)) == 1
        ),
        key=lambda edge: tuple(edge),
    ))
    edge_index = {edge: index for index, edge in enumerate(edges)}
    rank_two_faces = tuple(
        face for face in faces
        if len(face) >= 3 and affine_rank(tuple(coordinates[index] for index in face)) == 2
    )
    rows: list[list[Q]] = []
    for face in rank_two_faces:
        induced = {
            vertex: sorted(
                next(iter(edge - {vertex}))
                for edge in edges
                if vertex in edge and edge.issubset(face)
            )
            for vertex in face
        }
        assert all(len(neighbors) == 2 for neighbors in induced.values())
        start = min(face)
        previous = None
        current = start
        cycle = [start]
        while True:
            candidates = [neighbor for neighbor in induced[current] if neighbor != previous]
            assert candidates
            following = candidates[0]
            if following == start:
                break
            assert following not in cycle
            cycle.append(following)
            previous, current = current, following
        assert len(cycle) == len(face)
        for coordinate in range(len(coordinates[0])):
            row = [Q(0)] * len(edges)
            for position, vertex in enumerate(cycle):
                following = cycle[(position + 1) % len(cycle)]
                edge = frozenset((vertex, following))
                row[edge_index[edge]] += coordinates[following][coordinate] - coordinates[vertex][coordinate]
            rows.append(row)
    rank = matrix_rank(rows)
    nullity = len(edges) - rank
    assert all(sum(row, Q(0)) == 0 for row in rows)
    return {
        "edge_count": len(edges),
        "two_face_count": len(rank_two_faces),
        "edge_scaling_rank": rank,
        "edge_scaling_nullity": nullity,
        "minkowski_indecomposable": nullity == 1,
    }


@lru_cache(maxsize=None)
def is_zonotope_vertex_tuple(points_key: tuple[Vector, ...]) -> bool:
    points = tuple(sorted(points_key))
    dimension = affine_rank(points)
    if dimension == 0:
        return len(points) == 1
    if dimension == 1:
        return len(points) == 2 and centrally_symmetric(points)
    if not centrally_symmetric(points):
        return False
    coordinates = affine_coordinates(points)
    faces = two_faces(coordinates)
    if not faces:
        return False
    return all(centrally_symmetric(tuple(coordinates[index] for index in face)) for face in faces)


def is_zonotope_vertices(points: Sequence[Vector]) -> bool:
    return is_zonotope_vertex_tuple(tuple(sorted(points)))


def candidate_zonotope_masks(vertices: Sequence[Vector]) -> dict[int, int]:
    """Enumerate every centrally paired vertex subset and apply the exact criterion."""
    index_of = {vertex: index for index, vertex in enumerate(vertices)}
    masks: dict[int, int] = {1 << index: 0 for index in range(len(vertices))}
    centers = {
        scale(Q(1, 2), add(vertices[i], vertices[j]))
        for i in range(len(vertices))
        for j in range(i + 1, len(vertices))
    }
    for center in centers:
        pairs: list[tuple[int, int]] = []
        seen: set[int] = set()
        for index, vertex in enumerate(vertices):
            if index in seen:
                continue
            other = index_of.get(sub(scale(Q(2), center), vertex))
            if other is None or other == index:
                seen.add(index)
                continue
            pair = tuple(sorted((index, other)))
            if pair[0] not in seen and pair[1] not in seen:
                pairs.append(pair)
            seen.update(pair)
        for choice in range(1, 1 << len(pairs)):
            mask = 0
            for pair_index, pair in enumerate(pairs):
                if choice & (1 << pair_index):
                    mask |= (1 << pair[0]) | (1 << pair[1])
            points = tuple(vertices[index] for index in range(len(vertices)) if mask & (1 << index))
            if is_zonotope_vertices(points):
                masks[mask] = affine_rank(points)
    return masks


def self_test() -> dict[str, bool]:
    square = tuple((Q(x), Q(y)) for x, y in itertools.product((0, 1), repeat=2))
    cube = tuple((Q(x), Q(y), Q(z)) for x, y, z in itertools.product((0, 1), repeat=3))
    hypercube = tuple(
        tuple(Q(value) for value in point)
        for point in itertools.product((0, 1), repeat=4)
    )
    octahedron = tuple(
        tuple(Q(sign * int(index == axis)) for index in range(3))
        for axis in range(3)
        for sign in (-1, 1)
    )
    result = {
        "square": is_zonotope_vertices(square),
        "cube": is_zonotope_vertices(cube),
        "hypercube": is_zonotope_vertices(hypercube),
        "octahedron_rejected": not is_zonotope_vertices(octahedron),
    }
    assert all(result.values())
    return result


if __name__ == "__main__":
    print(self_test())
