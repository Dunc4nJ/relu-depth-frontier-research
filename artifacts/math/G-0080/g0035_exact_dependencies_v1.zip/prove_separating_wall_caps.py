#!/usr/bin/env python3
"""Exact P^2 obstruction for the factor-separating wall ``t = c``.

Let ``J2 = Delta_2 * square`` and ``0 < c < 1``.  The two caps are, up to
translation,

    L_c = (1-c) Delta_2 + c J2,
    U_c = c square + (1-c) J2.

The exact edge-scaling cones are simplicial:

    K(L_c) = cone(Delta_2, J2),
    K(U_c) = cone(segment_y1, segment_y2, J2).

To decide P^2 rather than merely primitive P^2, every possible Minkowski
summand carrying positive ``J2`` coefficient must be excluded as a primitive
block.  After normalizing that coefficient to one, this script asks exact Z3
linear real arithmetic whether the vertices can be covered by two centrally
symmetric subsets for every nonnegative choice of the other ray
coefficients.  Boundary support patterns are enumerated separately so that
contracted, non-extreme vertex images are never imposed as obligations.

Every query is UNSAT.  Hence no primitive block carries positive J2
coefficient; additivity of the complete type-cone coordinates then rules out
P^2 for both caps, for every real ``c`` strictly between zero and one.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
from fractions import Fraction as Q
from pathlib import Path
from typing import Sequence

import z3

from analyze_survivor_type_cones import (
    nullspace_basis,
    scaling_cone_rays,
    scaling_system,
    summand_vertex_map,
    summand_vertices,
)
from cone_join_obstruction import (
    affine_rank,
    join_edges_and_triangles,
    join_vertices,
    matrix_rank,
    z3_q,
)
from exact_zonotope import facets, null_vector, solve_square
from search_one_wall_refinements import cut_vertices, primitive_p2_partition


Vector = tuple[Q, ...]
SEPARATING_WALL = (-1, -1, -1, 1, 1, 1, 1)


def add(left: Sequence[Q], right: Sequence[Q]) -> Vector:
    return tuple(a + b for a, b in zip(left, right))


def sub(left: Sequence[Q], right: Sequence[Q]) -> Vector:
    return tuple(a - b for a, b in zip(left, right))


def scale(coefficient: Q, vector: Sequence[Q]) -> Vector:
    return tuple(coefficient * value for value in vector)


def dot(left: Sequence[Q], right: Sequence[Q]) -> Q:
    return sum((a * b for a, b in zip(left, right)), Q(0))


def all_one_coefficients(rays: Sequence[Vector]) -> tuple[Q, ...]:
    """Exact coefficients expressing the parent edge scaling in ray scalings."""
    ray_count = len(rays)
    edge_count = len(rays[0])
    rows = tuple(
        tuple(rays[ray][edge] for ray in range(ray_count))
        for edge in range(edge_count)
    )
    selected = next(
        combination
        for combination in itertools.combinations(rows, ray_count)
        if matrix_rank(combination) == ray_count
    )
    coefficients = solve_square(selected, (Q(1),) * ray_count)
    assert coefficients is not None
    assert all(coefficient > 0 for coefficient in coefficients)
    assert all(
        sum((coefficient * ray[edge] for coefficient, ray in zip(coefficients, rays)), Q(0)) == 1
        for edge in range(edge_count)
    )
    return coefficients


def facet_halfspaces(points: Sequence[Vector]) -> tuple[tuple[Vector, Q], ...]:
    """Oriented exact inequalities ``normal . x <= support``."""
    assert affine_rank(points) == len(points[0])
    output: list[tuple[Vector, Q]] = []
    for face in facets(points):
        selected = next(
            combination
            for combination in itertools.combinations(face, len(points[0]))
            if affine_rank(tuple(points[index] for index in combination)) == len(points[0]) - 1
        )
        kernel = null_vector(tuple((*points[index], Q(1)) for index in selected))
        assert kernel is not None
        values = tuple(dot((*point, Q(1)), kernel) for point in points)
        if all(value >= 0 for value in values):
            kernel = scale(Q(-1), kernel)
            values = tuple(-value for value in values)
        assert all(value <= 0 for value in values) and any(value < 0 for value in values)
        normal = kernel[:-1]
        support = -kernel[-1]
        assert max(dot(normal, point) for point in points) == support
        output.append((normal, support))
    return tuple(output)


def normalized_halfspace(normal: Sequence[Q], support: Q) -> tuple[int, ...]:
    """Canonicalize an oriented inequality up to positive rational scaling."""
    values = (*normal, support)
    denominator_lcm = math.lcm(*(value.denominator for value in values))
    integers = [value.numerator * (denominator_lcm // value.denominator) for value in values]
    divisor = math.gcd(*(abs(value) for value in integers if value))
    return tuple(value // divisor for value in integers)


def active_normal_ranks(
    points: Sequence[Vector],
    halfspaces: Sequence[tuple[Vector, Q]],
) -> tuple[int, ...]:
    """Rank of the exact active facet normals at every supplied point."""
    return tuple(
        matrix_rank(tuple(
            normal
            for normal, support in halfspaces
            if dot(normal, point) == support
        ))
        for point in points
    )


def verify_support_face_hrep(
    maps: Sequence[Sequence[Vector]],
    ray_polytopes: Sequence[Sequence[Vector]],
    full_halfspaces: Sequence[tuple[Vector, Q]],
    active_indices: Sequence[int],
) -> dict[str, int | bool]:
    """Check that inherited support inequalities exactly describe a cone face.

    Coefficients are set to one on the indicated rays.  Positive coefficients
    have the same common-refinement normal fan, so one relative-interior point
    suffices for the finite normal-fan check.
    """
    active = tuple(index in active_indices for index in range(len(maps)))
    representatives = representative_vertex_indices(maps, active)
    points = tuple(
        tuple(
            sum(
                (
                    maps[ray_index][vertex_index][coordinate]
                    for ray_index in active_indices
                ),
                Q(0),
            )
            for coordinate in range(len(maps[0][0]))
        )
        for vertex_index in representatives
    )
    assert affine_rank(points) == len(points[0])
    exact_facets = facet_halfspaces(points)
    inherited = []
    for normal, _support in full_halfspaces:
        support = sum(
            (
                max(dot(normal, vertex) for vertex in ray_polytopes[ray_index])
                for ray_index in active_indices
            ),
            Q(0),
        )
        assert all(dot(normal, point) <= support for point in points)
        inherited.append((normal, support))
    exact_keys = {normalized_halfspace(normal, support) for normal, support in exact_facets}
    inherited_keys = {normalized_halfspace(normal, support) for normal, support in inherited}
    assert exact_keys.issubset(inherited_keys)
    ranks = active_normal_ranks(points, inherited)
    dimension = len(points[0])
    assert ranks and min(ranks) == dimension
    return {
        "representative_vertex_count": len(points),
        "exact_facet_count": len(exact_keys),
        "inherited_inequality_count": len(inherited_keys),
        "every_exact_facet_inherited": True,
        "minimum_active_normal_rank": min(ranks),
        "ambient_dimension": dimension,
        "every_retained_image_proved_extreme": True,
    }


def ray_type(points: Sequence[Vector]) -> str:
    canonical = tuple(sorted(points))
    j2 = tuple(sorted(join_vertices(2)))
    triangle = tuple(sorted(join_vertices(2)[:3]))
    if canonical == j2:
        return "J2"
    if canonical == triangle:
        return "Delta_2"
    if len(canonical) == 2 and affine_rank(canonical) == 1:
        difference = sub(canonical[1], canonical[0])
        nonzero = [index for index, value in enumerate(difference) if value]
        assert len(nonzero) == 1 and nonzero[0] in (2, 3)
        return f"segment_y{nonzero[0] - 1}"
    raise AssertionError(f"unexpected ray summand: {canonical}")


def symbolic_sum(
    maps: Sequence[Sequence[Vector]],
    coefficients: Sequence[Q | z3.ArithRef],
    vertex_index: int,
) -> tuple[z3.ArithRef, ...]:
    return tuple(
        z3.Sum(*[
            (z3_q(coefficient) if isinstance(coefficient, Q) else coefficient)
            * z3_q(vertex_map[vertex_index][coordinate])
            for vertex_map, coefficient in zip(maps, coefficients)
        ])
        for coordinate in range(len(maps[0][0]))
    )


def representative_vertex_indices(
    maps: Sequence[Sequence[Vector]], active: Sequence[bool]
) -> tuple[int, ...]:
    """Vertices for the relative interior of one coefficient-support face."""
    seen: set[Vector] = set()
    representatives = []
    for vertex_index in range(len(maps[0])):
        point = tuple(
            sum(
                (
                    vertex_map[vertex_index][coordinate]
                    for vertex_map, enabled in zip(maps, active)
                    if enabled
                ),
                Q(0),
            )
            for coordinate in range(len(maps[0][0]))
        )
        if point not in seen:
            seen.add(point)
            representatives.append(vertex_index)
    return tuple(representatives)


def parametric_cover_query(
    maps: Sequence[Sequence[Vector]],
    ray_polytopes: Sequence[Sequence[Vector]],
    halfspaces: Sequence[tuple[Vector, Q]],
    bad_index: int,
    active_good_indices: Sequence[int],
    center_count: int = 2,
    want_proof: bool = False,
) -> tuple[z3.CheckSatResult, str | None, dict[str, object] | None]:
    """Two-center relaxation on one relative face of the coefficient cone."""
    active_good = frozenset(active_good_indices)
    coefficients: list[Q | z3.ArithRef] = []
    parameter_variables: dict[int, z3.ArithRef] = {}
    for ray_index in range(len(maps)):
        if ray_index == bad_index:
            coefficients.append(Q(1))
        elif ray_index in active_good:
            variable = z3.Real(f"theta_{bad_index}_{ray_index}_{center_count}")
            coefficients.append(variable)
            parameter_variables[ray_index] = variable
        else:
            coefficients.append(Q(0))
    active = tuple(
        index == bad_index or index in active_good
        for index in range(len(maps))
    )
    vertex_indices = representative_vertex_indices(maps, active)
    vertices = [symbolic_sum(maps, coefficients, index) for index in vertex_indices]
    centers = [
        [z3.Real(f"center_{bad_index}_{len(active_good)}_{center_count}_{group}_{coordinate}")
         for coordinate in range(len(maps[0][0]))]
        for group in range(center_count)
    ]
    colors = [
        z3.Int(f"color_{bad_index}_{len(active_good)}_{center_count}_{index}")
        for index in range(len(vertices))
    ]
    solver = z3.Solver()
    solver.add(*(variable > 0 for variable in parameter_variables.values()))
    solver.add(*(z3.And(color >= 0, color < center_count) for color in colors))
    supports = []
    for normal, _base_support in halfspaces:
        ray_supports = [max(dot(normal, vertex) for vertex in ray) for ray in ray_polytopes]
        supports.append(z3.Sum(*[
            (z3_q(coefficient) if isinstance(coefficient, Q) else coefficient)
            * z3_q(ray_support)
            for coefficient, ray_support in zip(coefficients, ray_supports)
        ]))
    for vertex_index, vertex in enumerate(vertices):
        for group in range(center_count):
            reflection = tuple(
                2 * centers[group][coordinate] - vertex[coordinate]
                for coordinate in range(len(vertex))
            )
            membership = z3.And(*[
                z3.Sum(*[
                    z3_q(normal[coordinate]) * reflection[coordinate]
                    for coordinate in range(len(normal))
                ])
                <= support
                for (normal, _), support in zip(halfspaces, supports)
            ])
            solver.add(z3.Implies(colors[vertex_index] == group, membership))
    result = solver.check()
    proof = str(solver.proof()) if want_proof and result == z3.unsat else None
    model_payload = None
    if result == z3.sat:
        model = solver.model()
        model_payload = {
            "parameters": {
                str(index): str(model.eval(variable, model_completion=True))
                for index, variable in parameter_variables.items()
            },
            "colors": [model.eval(color).as_long() for color in colors],
        }
    return result, proof, {
        "model": model_payload,
        "vertex_count": len(vertices),
        "active_good_ray_indices": sorted(active_good),
    }


def analyze_cap(side: int) -> dict[str, object]:
    vertices = join_vertices(2)
    edges, _triangles = join_edges_and_triangles(2)
    child = cut_vertices(vertices, edges, SEPARATING_WALL, side)
    translated = tuple(sub(point, child[0]) for point in child)
    cap_edges, rows = scaling_system(translated)
    basis = nullspace_basis(rows, len(cap_edges))
    rays = scaling_cone_rays(basis)
    assert matrix_rank(rays) == len(basis)
    coefficients = all_one_coefficients(rays)
    maps = tuple(summand_vertex_map(translated, cap_edges, ray) for ray in rays)
    polytopes = tuple(tuple(sorted(set(vertex_map))) for vertex_map in maps)
    types = tuple(ray_type(polytope) for polytope in polytopes)
    assert types.count("J2") == 1
    bad_index = types.index("J2")
    good_indices = tuple(index for index in range(len(rays)) if index != bad_index)
    assert all(primitive_p2_partition(polytopes[index]) is not None for index in good_indices)
    assert primitive_p2_partition(polytopes[bad_index]) is None

    # The ray integration must reconstruct the cap exactly at the all-one
    # edge-scaling coefficients, vertex by vertex up to the chosen translation.
    for vertex_index, point in enumerate(translated):
        reconstructed = tuple(
            sum(
                (
                    coefficient * vertex_map[vertex_index][coordinate]
                    for coefficient, vertex_map in zip(coefficients, maps)
                ),
                Q(0),
            )
            for coordinate in range(len(point))
        )
        assert reconstructed == point

    halfspaces = facet_halfspaces(translated)
    interior_mutant = tuple(
        sum((point[coordinate] for point in translated), Q(0)) / len(translated)
        for coordinate in range(len(translated[0]))
    )
    original_ranks = active_normal_ranks(translated, halfspaces)
    mutant_ranks = active_normal_ranks((*translated, interior_mutant), halfspaces)
    assert min(original_ranks) == len(translated[0])
    assert mutant_ranks[-1] < len(translated[0])
    queries = []
    proof_sample = None
    for subset_size in range(len(good_indices) + 1):
        for subset in itertools.combinations(good_indices, subset_size):
            hrep_check = verify_support_face_hrep(
                maps,
                polytopes,
                halfspaces,
                (bad_index, *subset),
            )
            result, proof, metadata = parametric_cover_query(
                maps,
                polytopes,
                halfspaces,
                bad_index,
                subset,
                want_proof=proof_sample is None,
            )
            assert metadata is not None
            record = {
                "active_good_ray_types": [types[index] for index in subset],
                "normalized_J2_coefficient": 1,
                "strictly_positive_active_coefficients": True,
                "two_center_cover": str(result),
                "vertex_count": metadata["vertex_count"],
                "hrep_check": hrep_check,
            }
            queries.append(record)
            assert result == z3.unsat
            if proof_sample is None:
                assert proof is not None
                proof_sample = {
                    "active_good_ray_types": record["active_good_ray_types"],
                    "proof_chars": len(proof),
                    "proof_sha256": hashlib.sha256(proof.encode()).hexdigest(),
                }

    # Potency control: on the full-support coefficient face, one point-center
    # per vertex makes the same reflection-membership encoding SAT.
    full_vertex_count = queries[-1]["vertex_count"]
    potency, _proof, potency_metadata = parametric_cover_query(
        maps,
        polytopes,
        halfspaces,
        bad_index,
        good_indices,
        center_count=int(full_vertex_count),
    )
    assert potency == z3.sat and potency_metadata is not None

    return {
        "side": side,
        "cap_vertex_count": len(child),
        "cap_affine_dimension": affine_rank(child),
        "edge_count": len(cap_edges),
        "edge_scaling_rank": len(cap_edges) - len(basis),
        "edge_scaling_nullity": len(basis),
        "complete_nonnegative_type_cone_extreme_rays": [
            {
                "index": index,
                "type": ray_type(polytope),
                "vertex_count": len(polytope),
                "affine_dimension": affine_rank(polytope),
                "primitive_p2_partition": primitive_p2_partition(polytope),
            }
            for index, polytope in enumerate(polytopes)
        ],
        "cap_all_one_edge_scaling_coefficients": [
            [coefficient.numerator, coefficient.denominator]
            for coefficient in coefficients
        ],
        "J2_ray_index": bad_index,
        "parametric_primitive_obstruction_queries": queries,
        "all_J2_positive_coefficient_support_faces_unsat": True,
        "unsat_proof_sample": proof_sample,
        "potency_one_center_per_vertex": str(potency),
        "extreme_vertex_control": {
            "minimum_active_normal_rank_on_cap_vertices": min(original_ranks),
            "ambient_dimension": len(translated[0]),
            "planted_interior_barycenter_active_normal_rank": mutant_ranks[-1],
            "planted_nonvertex_rejected": True,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    z3.set_param(proof=True)
    lower = analyze_cap(-1)
    upper = analyze_cap(1)
    assert lower["edge_scaling_nullity"] == 2
    assert upper["edge_scaling_nullity"] == 3
    assert [ray["type"] for ray in lower["complete_nonnegative_type_cone_extreme_rays"]] == [
        "Delta_2", "J2"
    ]
    assert sorted(ray["type"] for ray in upper["complete_nonnegative_type_cone_extreme_rays"]) == [
        "J2", "segment_y1", "segment_y2"
    ]
    report = {
        "schema": "g0035-factor-separating-wall-cap-obstruction-v1",
        "arithmetic": "fractions.Fraction plus Z3 exact QF_LRA with proof generation",
        "wall": "t=c in J2=Delta_2*square, with arbitrary real 0<c<1",
        "cap_identities_up_to_translation": {
            "lower": "L_c=(1-c) Delta_2 + c J2",
            "upper": "U_c=c square + (1-c) J2",
        },
        "caps": [lower, upper],
        "theorem": (
            "For every real 0<c<1, neither cap belongs to P2. The complete type cones force "
            "some primitive summand in any putative P2 expression to carry positive J2 ray "
            "coefficient, while the exhaustive coefficient-support LRA queries prove that no "
            "such summand admits even the necessary two-centrally-symmetric-set vertex cover."
        ),
        "scope": (
            "This closes the constant-on-factor representative of off-vertex sign pattern A. "
            "It does not close unequal wall ratios in that sign orthant, sign patterns B/C, "
            "two-wall refinements, other subdivisions, virtual S2 cancellation, or MAX11."
        ),
        "result": "PASS",
        "source_sha256": {
            "analyze_survivor_type_cones.py": hashlib.sha256(
                Path(__file__).with_name("analyze_survivor_type_cones.py").read_bytes()
            ).hexdigest(),
            "classify_off_vertex_walls.py": hashlib.sha256(
                Path(__file__).with_name("classify_off_vertex_walls.py").read_bytes()
            ).hexdigest(),
            "exact_zonotope.py": hashlib.sha256(
                Path(__file__).with_name("exact_zonotope.py").read_bytes()
            ).hexdigest(),
        },
        "z3_version": z3.get_version_string(),
    }
    encoded = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(encoded)
    print(json.dumps({
        "schema": report["schema"],
        "lower_type_cone": [
            ray["type"] for ray in lower["complete_nonnegative_type_cone_extreme_rays"]
        ],
        "upper_type_cone": [
            ray["type"] for ray in upper["complete_nonnegative_type_cone_extreme_rays"]
        ],
        "lower_queries": len(lower["parametric_primitive_obstruction_queries"]),
        "upper_queries": len(upper["parametric_primitive_obstruction_queries"]),
        "result": report["result"],
    }, sort_keys=True))


if __name__ == "__main__":
    main()
